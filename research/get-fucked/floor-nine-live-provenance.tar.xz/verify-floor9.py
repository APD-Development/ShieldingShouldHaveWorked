from pathlib import Path
import subprocess,json,sys
r=Path.cwd()/'research'
for name,start,end,props in json.loads((r/'floor9-cases.json').read_text()):
 start=r/('earned-'+start[5:].replace('_','-')) if start.startswith('repo:') else r/start
 cmd=['python','research/run_route.py','research/floor9-'+name+'.native.verify.log','-XX:+UnlockExperimentalVMOptions','-XX:hashCode=2','-Droute.resume='+str(start),'-Droute.expectedEnd='+str(r/end),'-Droute.expectedNativeState=true']+['-D'+k+'='+v for k,v in props.items()]
 with (r/('floor9-'+name+'.native.verify.summary')).open('w') as out:p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 print(name,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
