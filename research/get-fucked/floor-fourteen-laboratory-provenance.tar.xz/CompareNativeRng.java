import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Read-only equivalent of GetFuckedRouteTest's active gameplay RNG comparison. */
public final class CompareNativeRng {
    private static ArrayDeque<?> read(String directory) throws Exception {
        try (ObjectInputStream in = new ObjectInputStream(Files.newInputStream(Path.of(directory, "rng.bin")))) {
            return (ArrayDeque<?>) in.readObject();
        }
    }
    private static byte[] serialize(Object value) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ObjectOutputStream out = new ObjectOutputStream(bytes)) { out.writeObject(value); }
        return bytes.toByteArray();
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("Expected two native checkpoint directories");
        ArrayDeque<?> expected = read(args[0]), actual = read(args[1]);
        if (expected.isEmpty() || expected.size() != actual.size()) throw new AssertionError("RNG stack depths differ or are empty");
        if (!Arrays.equals(serialize(expected.peekFirst()), serialize(actual.peekFirst()))) throw new AssertionError("Active gameplay RNG differs");
        System.out.println("ACTIVE_GAMEPLAY_RNG_PASS stackDepth=" + expected.size() + " inactiveBaseNotCompared=true");
    }
}
