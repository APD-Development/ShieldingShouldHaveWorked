package com.shatteredpixel.shatteredpixeldungeon.actors.hero;

import com.shatteredpixel.shatteredpixeldungeon.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.*;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mob;
import com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Blob;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.spells.*;
import com.shatteredpixel.shatteredpixeldungeon.apd.*;
import com.shatteredpixel.shatteredpixeldungeon.effects.*;
import com.shatteredpixel.shatteredpixeldungeon.items.*;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.*;
import com.shatteredpixel.shatteredpixeldungeon.levels.*;
import com.shatteredpixel.shatteredpixeldungeon.scenes.*;
import com.shatteredpixel.shatteredpixeldungeon.sprites.*;
import com.watabou.noosa.*;
import com.watabou.noosa.particles.Emitter;
import com.watabou.utils.*;
import com.watabou.utils.Random;
import org.json.*;
import org.junit.*;
import org.mockito.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;

/** Fixed commands in the production Actor.process scheduler. No action policy or combat model. */
public class GetFuckedRouteTest {
    @Rule public org.junit.rules.Timeout deadline = org.junit.rules.Timeout.seconds(45);
    private final List<MockedStatic<?>> visuals = new ArrayList<>();
    private CellSelector.Listener selection;
    private com.shatteredpixel.shatteredpixeldungeon.windows.WndBag.ItemSelector itemSelection;
    private MockedConstruction<com.shatteredpixel.shatteredpixeldungeon.windows.WndUpgrade> upgradeWindows;
    private Object upgradeButton;
    private MockedConstruction<com.shatteredpixel.shatteredpixeldungeon.windows.WndTradeItem> tradeWindows;
    private com.shatteredpixel.shatteredpixeldungeon.windows.WndTradeItem tradeWindow;
    private Heap tradeHeap;
    private boolean executeTradeUi;
    private boolean executeChasmUi;
    private MockedConstruction<?> chasmWindows;
    private Object chasmWindow;
    private MockedConstruction<?> hourglassWindows;
    private Object hourglassWindow;
    private Camera oldMainCamera;
    private int chainAnimationsCompleted;
    private int pushAnimationsCompleted;
    private AtomicBoolean watch;
    private Thread watchdog;
    private boolean oldKeepAlive;
    private boolean pendingTransition;
    private boolean pendingAlchemy;
    private com.watabou.noosa.Scene currentTestScene;
    private GameScene gameplaySceneStub;
    private com.shatteredpixel.shatteredpixeldungeon.ui.TargetHealthIndicator oldTargetIndicator;

    private void bind(Char ch) {
        if (ch.sprite != null) return;
        CharSprite sprite = ch == Dungeon.hero ? mock(HeroSprite.class, RETURNS_DEEP_STUBS)
                : ch instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Goo ? mock(com.shatteredpixel.shatteredpixeldungeon.sprites.GooSprite.class,RETURNS_DEEP_STUBS)
                : ch instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Necromancer ? mock(com.shatteredpixel.shatteredpixeldungeon.sprites.NecromancerSprite.class,RETURNS_DEEP_STUBS) : mock(CharSprite.class, RETURNS_DEEP_STUBS);
        ch.sprite = sprite;
        if(ch instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Goo)doAnswer(i->{ch.onAttackComplete();return null;}).when((com.shatteredpixel.shatteredpixeldungeon.sprites.GooSprite)sprite).pumpAttack();
        if(ch instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Necromancer)
            doAnswer(i->{com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Necromancer necro=(com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Necromancer)ch;if(!necro.summoning)necro.onZapComplete();return null;}).when(sprite).zap(anyInt());
        if(ch==Dungeon.hero)doAnswer(i -> {ch.onOperateComplete();return null;}).when((HeroSprite)sprite).read();
        Group parent=mock(Group.class,i -> {
            if(i.getMethod().getName().equals("recycle") && i.getArguments().length==1 && i.getArgument(0) instanceof Class)
                return mock((Class<?>)i.getArgument(0),RETURNS_DEEP_STUBS);
            if(i.getMethod().getName().equals("add") && i.getArguments().length==1
                    && (i.getArgument(0) instanceof com.shatteredpixel.shatteredpixeldungeon.effects.Chains
                    || i.getArgument(0) instanceof com.shatteredpixel.shatteredpixeldungeon.effects.Pushing.Effect)){
                com.watabou.noosa.Gizmo effect=i.getArgument(0);float before=Game.elapsed;
                try{Game.elapsed=100f;effect.update();}finally{Game.elapsed=before;}
                if(effect instanceof com.shatteredpixel.shatteredpixeldungeon.effects.Chains)chainAnimationsCompleted++;
                else pushAnimationsCompleted++;
                System.out.println("ANIMATION_CALLBACK_COMPLETED "+effect.getClass().getName());
                return effect;
            }
            return Answers.RETURNS_DEEP_STUBS.answer(i);
        }); sprite.parent=parent;
        MissileSprite missile=mock(MissileSprite.class);
        when(parent.recycle(MissileSprite.class)).thenReturn(missile);
        doAnswer(i -> {((Callback)i.getArgument(3)).call();return null;}).when(missile).reset(any(Visual.class),any(Visual.class),any(Item.class),any(Callback.class));
        doAnswer(i -> {((Callback)i.getArgument(3)).call();return null;}).when(missile).reset(any(Visual.class),anyInt(),any(Item.class),any(Callback.class));
        when(sprite.center()).thenReturn(new PointF());
        doAnswer(i -> { ch.onAttackComplete(); return null; }).when(sprite).attack(anyInt());
        doAnswer(i -> { ch.onOperateComplete(); return null; }).when(sprite).operate(anyInt());
        doAnswer(i -> { ch.onMotionComplete(); return null; }).when(sprite).move(anyInt(), anyInt());
    }
    private void heapSprite(Heap h) {
        if(h.sprite==null){h.sprite=mock(ItemSprite.class,RETURNS_DEEP_STUBS);when(h.sprite.view(any(Heap.class))).thenReturn(h.sprite);}
    }
    private void bindBlobVisuals(){
        for(Blob b:Dungeon.level.blobs.values())if(b instanceof com.shatteredpixel.shatteredpixeldungeon.actors.blobs.SacrificialFire)
            b.use(mock(com.shatteredpixel.shatteredpixeldungeon.effects.BlobEmitter.class));
    }
    private <T> MockedStatic<T> visual(Class<T> type) {
        MockedStatic<T> m = mockStatic(type); visuals.add(m); return m;
    }
    @Before public void init() throws Exception {
        System.out.println("RUNNER_STAGE initialize");
        HeadlessTestSupport.start();
        oldMainCamera=Camera.main;Camera.main=mock(Camera.class);
        MockedStatic<GameScene> scene = mockStatic(GameScene.class, invocation -> {
            Object[] args = invocation.getArguments();
            if(invocation.getMethod().getName().equals("selectItem")){
                itemSelection=(com.shatteredpixel.shatteredpixeldungeon.windows.WndBag.ItemSelector)args[0];
            }else if (invocation.getMethod().getName().equals("selectCell")) {
                selection = (CellSelector.Listener) args[0];
            } else if (invocation.getMethod().getName().equals("add") && args.length > 0) {
                if (args[0] instanceof Mob) {
                    Mob mob = (Mob)args[0];
                    float delay = args.length == 2 ? ((Number)args[1]).floatValue() : 0;
                    Dungeon.level.mobs.add(mob); bind(mob);
                    Actor.addDelayed(mob, (float)Math.ceil(Actor.now()+delay)-Actor.now());
                    mob.spendToWhole();
                } else if (args[0] instanceof Blob) Actor.add((Blob)args[0]);
                else if (args[0] instanceof Heap) heapSprite((Heap)args[0]);
            }
            return Answers.RETURNS_DEFAULTS.answer(invocation);
        });
        visuals.add(scene);
        upgradeWindows=mockConstruction(com.shatteredpixel.shatteredpixeldungeon.windows.WndUpgrade.class,(window,contextArgs)->{
            Class<?> buttonClass=Class.forName("com.shatteredpixel.shatteredpixeldungeon.windows.WndUpgrade$1");
            upgradeButton=mock(buttonClass,CALLS_REAL_METHODS);
            String[] fields={"this$0","val$upgrader","val$toUpgrade","val$force"};
            Object[] values={window,contextArgs.arguments().get(0),contextArgs.arguments().get(1),contextArgs.arguments().get(2)};
            for(int n=0;n<fields.length;n++){Field f=buttonClass.getDeclaredField(fields[n]);f.setAccessible(true);f.set(upgradeButton,values[n]);}
        });
        tradeWindows=mockConstruction(com.shatteredpixel.shatteredpixeldungeon.windows.WndTradeItem.class,(window,contextArgs)->{
            if(contextArgs.arguments().size()==1 && contextArgs.arguments().get(0) instanceof Heap){tradeWindow=window;tradeHeap=(Heap)contextArgs.arguments().get(0);}
        });
        Class jumpWindowClass=Class.forName("com.shatteredpixel.shatteredpixeldungeon.levels.features.Chasm$1$1");
        chasmWindows=mockConstruction(jumpWindowClass,withSettings().defaultAnswer(CALLS_REAL_METHODS),(window,contextArgs)->{chasmWindow=window;Field outer=window.getClass().getDeclaredField("this$0");outer.setAccessible(true);outer.set(window,contextArgs.arguments().get(0));});
        Class freezeWindowClass=Class.forName("com.shatteredpixel.shatteredpixeldungeon.items.artifacts.TimekeepersHourglass$1");
        hourglassWindows=mockConstruction(freezeWindowClass,withSettings().defaultAnswer(CALLS_REAL_METHODS),(window,contextArgs)->{hourglassWindow=window;Field outer=window.getClass().getDeclaredField("this$0");outer.setAccessible(true);outer.set(window,contextArgs.arguments().get(0));});
        MockedStatic<Game> game=visual(Game.class);
        game.when(()->Game.runOnRenderThread(any(Callback.class))).thenAnswer(i->{if(executeTradeUi || executeChasmUi)((Callback)i.getArgument(0)).call();return null;});
        gameplaySceneStub=mock(GameScene.class,RETURNS_DEEP_STUBS);
        game.when(Game::scene).thenAnswer(i->currentTestScene);
        game.when(() -> Game.switchScene(InterlevelScene.class)).thenAnswer(i -> { pendingTransition=true; currentTestScene=mock(InterlevelScene.class,RETURNS_DEEP_STUBS); return null; });
        game.when(() -> Game.switchScene(AlchemyScene.class)).thenAnswer(i -> {pendingAlchemy=true;currentTestScene=mock(AlchemyScene.class,RETURNS_DEEP_STUBS);return null;});
        oldTargetIndicator=com.shatteredpixel.shatteredpixeldungeon.ui.TargetHealthIndicator.instance;
        com.shatteredpixel.shatteredpixeldungeon.ui.TargetHealthIndicator.instance=mock(com.shatteredpixel.shatteredpixeldungeon.ui.TargetHealthIndicator.class,CALLS_REAL_METHODS);
        MockedStatic<com.shatteredpixel.shatteredpixeldungeon.ui.AttackIndicator> attackIndicator=visual(com.shatteredpixel.shatteredpixeldungeon.ui.AttackIndicator.class);
        attackIndicator.when(() -> com.shatteredpixel.shatteredpixeldungeon.ui.AttackIndicator.target(any()))
                .thenAnswer(i -> {com.shatteredpixel.shatteredpixeldungeon.ui.QuickSlotButton.target(i.getArgument(0));return null;});
        visual(Enchanting.class);
        visual(SpellSprite.class);
        MockedStatic<CellEmitter> cells = visual(CellEmitter.class);
        Emitter emitter = mock(Emitter.class);
        cells.when(() -> CellEmitter.get(anyInt())).thenReturn(emitter);
        cells.when(() -> CellEmitter.center(anyInt())).thenReturn(emitter);
        cells.when(() -> CellEmitter.bottom(anyInt())).thenReturn(emitter);
        cells.when(() -> CellEmitter.floor(anyInt())).thenReturn(emitter);
        MockedStatic<MagicMissile> missiles = mockStatic(MagicMissile.class, i -> {
            Object[] args = i.getArguments();
            if (i.getMethod().getName().equals("boltFromChar")) ((Callback)args[args.length-1]).call();
            return null;
        });
        visuals.add(missiles);
        System.out.println("RUNNER_STAGE visuals bound");
        Method context = LevelGenerationHarness.class.getDeclaredMethod("applyContext", LevelGenerationHarness.Context.class);
        context.setAccessible(true); context.invoke(null, LevelGenerationHarness.Context.REFERENCE);
        SPDSettings.challenges(Challenges.GET_FUCKED);
        Dungeon.daily = Dungeon.dailyReplay = false;
        Dungeon.customSeedText = ""; Dungeon.seed = 266L;
        GamesInProgress.selectedClass = HeroClass.CLERIC;
        GamesInProgress.randomizedClass = false; GamesInProgress.curSlot = 1;
        String resume=System.getProperty("route.resume");
        if(resume==null){
            java.nio.file.Path freshSlot=FileUtils.getFileHandle(GamesInProgress.gameFile(1)).file().toPath().getParent();
            java.nio.file.Files.createDirectories(freshSlot);
            try(java.nio.file.DirectoryStream<java.nio.file.Path> files=java.nio.file.Files.newDirectoryStream(freshSlot,"*.dat")){
                for(java.nio.file.Path file:files)java.nio.file.Files.delete(file);
            }
            Dungeon.init();
            Random.pushGenerator(266L);
            Dungeon.depth=1;Dungeon.branch=0;Dungeon.level=Dungeon.newLevel();
            bind(Dungeon.hero);for(Mob m:Dungeon.level.mobs)bind(m);
            for(Heap h:Dungeon.level.heaps.valueList())heapSprite(h);
            Dungeon.switchLevel(Dungeon.level,-1);
        }else{
            restoreCheckpoint(resume);
        }
        currentTestScene=gameplaySceneStub;
        bindBlobVisuals();
        System.out.println("RUNNER_STAGE actual level entered");
        oldKeepAlive = Actor.keepActorThreadAlive;
        Actor.keepActorThreadAlive = false;
        //Actor.process has a public stop flag, but waits once when an animation/input pauses it.
        //Release only that wait. The production scheduler still selects and acts every actor.
        Thread test = Thread.currentThread(); watch = new AtomicBoolean(true);
        watchdog = new Thread(() -> {
            while (watch.get()) {
                if (test.getState() == Thread.State.WAITING) synchronized(test) { test.notifyAll(); }
                try { Thread.sleep(1); } catch (InterruptedException e) { return; }
            }
        });
        watchdog.setDaemon(true); watchdog.start();
    }
    @After public void close() throws Exception {
        if (watch != null) { watch.set(false); watchdog.interrupt(); watchdog.join(1000); }
        Actor.keepActorThreadAlive = oldKeepAlive;
        Camera.main=oldMainCamera;
        com.shatteredpixel.shatteredpixeldungeon.ui.TargetHealthIndicator.instance=oldTargetIndicator;
        Actor.clear(); Random.popGenerator();
        if(upgradeWindows!=null)upgradeWindows.close();
        if(tradeWindows!=null)tradeWindows.close();
        if(chasmWindows!=null)chasmWindows.close();
        if(hourglassWindows!=null)hourglassWindows.close();
        Collections.reverse(visuals); for (MockedStatic<?> m : visuals) m.close();
    }
    private void ready() {
        for (int steps=0; steps<10000; steps++) {
            if(pendingTransition){
                pendingTransition=false;
                try {
                    Actor.fixTime();
                    InterlevelScene scene=mock(InterlevelScene.class,CALLS_REAL_METHODS);
                    Method transition=InterlevelScene.class.getDeclaredMethod(InterlevelScene.mode==InterlevelScene.Mode.DESCEND ? "descend" : InterlevelScene.mode==InterlevelScene.Mode.FALL ? "fall" : "ascend");
                    transition.setAccessible(true);transition.invoke(scene);
                    currentTestScene=gameplaySceneStub;
                    bindBlobVisuals();
                    bind(Dungeon.hero);for(Mob m:Dungeon.level.mobs)bind(m);
                    for(Heap h:Dungeon.level.heaps.valueList())heapSprite(h);
                    if(InterlevelScene.mode==InterlevelScene.Mode.FALL)Dungeon.hero.busy();
                }catch(Exception e){throw new RuntimeException(e);}
            }
            if (!Dungeon.hero.isAlive()) throw new AssertionError("Terminal hero state: "+state("DEATH"));
            if (Dungeon.hero.ready && Dungeon.hero.cooldown()<=0.0001f && Dungeon.hero.paralysed==0) return;
            if(Boolean.getBoolean("route.audit") && Dungeon.depth==2 && Actor.now()>=63){
                try{
                    Field f=Actor.class.getDeclaredField("all");f.setAccessible(true);
                    Field priority=Actor.class.getDeclaredField("actPriority");priority.setAccessible(true);
                    Actor selected=null;float earliest=Float.MAX_VALUE;
                    for(Actor a:(Set<Actor>)f.get(null)){
                        float t=Actor.now()+a.cooldown();
                        if(t<earliest || t==earliest && (selected==null || priority.getInt(a)>priority.getInt(selected))){selected=a;earliest=t;}
                    }
                    System.out.println("SCHEDULE "+Actor.now()+" next="+selected.getClass().getSimpleName()+":"+selected.apdPeekId()+" at="+earliest+" hero="+Dungeon.hero.pos+" heroTime="+(Actor.now()+Dungeon.hero.cooldown())+" action="+Dungeon.hero.curAction);
                }catch(Exception e){throw new RuntimeException(e);}
            }
            Actor.process();
        }
        throw new AssertionError("No input boundary: "+state("STALL"));
    }
    private int charge(HolyTome t) throws Exception {
        Field f = Artifact.class.getDeclaredField("charge"); f.setAccessible(true); return f.getInt(t);
    }
    private JSONObject continuity() throws Exception {
        JSONObject j=state("CONTINUITY");
        j.remove("command");j.remove("mobs");j.remove("heaps");j.remove("ironKeys");j.remove("goldenKeys");
        JSONArray inventory=j.getJSONArray("inventory");List<String> sorted=new ArrayList<>();
        for(int n=0;n<inventory.length();n++)sorted.add(inventory.getString(n));Collections.sort(sorted);j.put("inventory",new JSONArray(sorted));
        JSONArray mobSet=new JSONArray();List<String> mobs=new ArrayList<>();
        for(Mob m:Dungeon.level.mobs)mobs.add(m.apdPeekId()+":"+m.getClass().getSimpleName()+":"+m.pos+":"+m.HP+":"+m.cooldown());
        Collections.sort(mobs);j.put("mobs",new JSONArray(mobs));
        Field f=Artifact.class.getDeclaredField("partialCharge");f.setAccessible(true);j.put("partialCharge",f.getFloat(Dungeon.hero.belongings.getItem(HolyTome.class)));
        j.put("talents",Dungeon.hero.talents.toString());j.put("gold",Dungeon.gold).put("energy",Dungeon.energy).put("challenges",Dungeon.challenges);
        TimekeepersHourglass hourglass=Dungeon.hero.belongings.getItem(TimekeepersHourglass.class);
        if(hourglass!=null){
            Field whole=Artifact.class.getDeclaredField("charge");whole.setAccessible(true);
            j.put("hourglassCharge",whole.getInt(hourglass)).put("hourglassPartial",f.getFloat(hourglass));
            j.put("hourglassEquipped",hourglass.isEquipped(Dungeon.hero)).put("hourglassCursed",hourglass.cursed);
        }
        return j;
    }
    private void writeCheckpoint(String dir) throws Exception {
        //Normal native save of the earned run, including all previously visited floors. Never construct a replacement hero.
        Dungeon.saveAll();
        java.nio.file.Path output=java.nio.file.Paths.get(dir);java.nio.file.Files.createDirectories(output);
        java.nio.file.Path nativeDir=FileUtils.getFileHandle(GamesInProgress.gameFile(1)).file().toPath().getParent();
        JSONArray savedFiles=new JSONArray();
        try(java.nio.file.DirectoryStream<java.nio.file.Path> files=java.nio.file.Files.newDirectoryStream(nativeDir,"*.dat")){
            for(java.nio.file.Path file:files){java.nio.file.Files.copy(file,output.resolve(file.getFileName()),java.nio.file.StandardCopyOption.REPLACE_EXISTING);savedFiles.put(file.getFileName().toString());}
        }
        Field f=Random.class.getDeclaredField("generators");f.setAccessible(true);
        try(java.io.ObjectOutputStream out=new java.io.ObjectOutputStream(java.nio.file.Files.newOutputStream(output.resolve("rng.bin")))){out.writeObject(f.get(null));}
        JSONObject manifest=new JSONObject().put("state",continuity()).put("seed",266).put("format","APD native save plus captured RNG, earned by commands from level one").put("files",savedFiles);
        java.nio.file.Files.write(output.resolve("manifest.json"),manifest.toString(2).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        log("NATIVE_CHECKPOINT_WRITTEN");
    }
    private void restoreCheckpoint(String dir) throws Exception {
        java.nio.file.Path input=java.nio.file.Paths.get(dir);
        JSONObject manifest=new JSONObject(new String(java.nio.file.Files.readAllBytes(input.resolve("manifest.json")),java.nio.charset.StandardCharsets.UTF_8));
        int depth=manifest.getJSONObject("state").getInt("depth");
        java.nio.file.Files.createDirectories(FileUtils.getFileHandle(GamesInProgress.gameFile(1)).file().toPath().getParent());
        java.nio.file.Path nativeDir=FileUtils.getFileHandle(GamesInProgress.gameFile(1)).file().toPath().getParent();
        //The checkpoint is the complete retained run. Discard only stale files from other test runs.
        try(java.nio.file.DirectoryStream<java.nio.file.Path> oldFiles=java.nio.file.Files.newDirectoryStream(nativeDir,"*.dat")){
            for(java.nio.file.Path oldFile:oldFiles)java.nio.file.Files.delete(oldFile);
        }
        try(java.nio.file.DirectoryStream<java.nio.file.Path> files=java.nio.file.Files.newDirectoryStream(input,"*.dat")){
            for(java.nio.file.Path file:files)java.nio.file.Files.copy(file,nativeDir.resolve(file.getFileName()),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }
        Badges.loadGlobal();Dungeon.loadGame(1);
        for(int d=1;d<=Statistics.deepestFloor;d++)assertTrue("Missing previously visited floor "+d,java.nio.file.Files.exists(FileUtils.getFileHandle(GamesInProgress.depthFile(1,d,0)).file().toPath()));
        Dungeon.level=Dungeon.loadLevel(1);
        bind(Dungeon.hero);for(Mob m:Dungeon.level.mobs)bind(m);
        for(Heap h:Dungeon.level.heaps.valueList())heapSprite(h);
        Dungeon.switchLevel(Dungeon.level,Dungeon.hero.pos);
        Field f=Random.class.getDeclaredField("generators");f.setAccessible(true);
        try(java.io.ObjectInputStream in=new java.io.ObjectInputStream(java.nio.file.Files.newInputStream(input.resolve("rng.bin")))){f.set(null,in.readObject());}
    }
    private void verifyCheckpoint(String dir) throws Exception {
        JSONObject manifest=new JSONObject(new String(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(dir,"manifest.json")),java.nio.charset.StandardCharsets.UTF_8));
        JSONObject expected=manifest.getJSONObject("state"),actual=continuity();
        assertTrue("Native restore changed retained resources: expected="+expected+" actual="+actual,expected.similar(new JSONObject(actual.toString())));
        log("NATIVE_CONTINUITY_VERIFIED");
    }
    private void verifyExpectedEnd() throws Exception {
        String path=System.getProperty("route.expectedEnd");if(path==null)return;
        java.nio.file.Path root=java.nio.file.Paths.get(path);
        JSONObject expected=new JSONObject(new String(java.nio.file.Files.readAllBytes(root.resolve("manifest.json")),java.nio.charset.StandardCharsets.UTF_8)).getJSONObject("state");
        JSONObject actual=continuity();actual.put("time",0);
        assertTrue("Endpoint resources differ from the connected native checkpoint: expected="+expected+" actual="+actual,expected.similar(new JSONObject(actual.toString())));
        Field f=Random.class.getDeclaredField("generators");f.setAccessible(true);
        java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();
        try(java.io.ObjectOutputStream out=new java.io.ObjectOutputStream(bytes)){out.writeObject(f.get(null));}
        if(Boolean.getBoolean("route.expectedActiveRngOnly")){
            Object expectedStack;
            try(java.io.ObjectInputStream in=new java.io.ObjectInputStream(java.nio.file.Files.newInputStream(root.resolve("rng.bin")))){expectedStack=in.readObject();}
            java.util.ArrayDeque<?> expectedGenerators=(java.util.ArrayDeque<?>)expectedStack,actualGenerators=(java.util.ArrayDeque<?>)f.get(null);
            assertEquals("RNG stack depth differs",expectedGenerators.size(),actualGenerators.size());
            java.io.ByteArrayOutputStream a=new java.io.ByteArrayOutputStream(),b=new java.io.ByteArrayOutputStream();
            try(java.io.ObjectOutputStream out=new java.io.ObjectOutputStream(a)){out.writeObject(expectedGenerators.peekFirst());}
            try(java.io.ObjectOutputStream out=new java.io.ObjectOutputStream(b)){out.writeObject(actualGenerators.peekFirst());}
            assertArrayEquals("Active gameplay RNG differs",a.toByteArray(),b.toByteArray());
            System.out.println("CONNECTED_ENDPOINT_STATE_AND_ACTIVE_RNG_VERIFIED_INACTIVE_BASE_NOT_COMPARED "+root.getFileName());
        }else{
            assertArrayEquals("Endpoint RNG differs from the connected native checkpoint",java.nio.file.Files.readAllBytes(root.resolve("rng.bin")),bytes.toByteArray());
            System.out.println("CONNECTED_ENDPOINT_STATE_AND_RNG_VERIFIED "+root.getFileName());
        }
    }

    private void snapshot(String label) throws Exception {
        if(Boolean.getBoolean("route.noSnapshots")) return;
        Bundle b=new Bundle();
        b.put("hero",Dungeon.hero); b.put("level",Dungeon.level);
        Bundle gen=new Bundle(); Generator.storeInBundle(gen); b.put("generator",gen);
        Bundle stats=new Bundle(); Statistics.storeInBundle(stats); b.put("statistics",stats);
        java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();
        Bundle.write(b,out,false);
        System.out.println("SNAPSHOT266 "+label+" "+Base64.getEncoder().encodeToString(out.toByteArray()));
        Field generators=Random.class.getDeclaredField("generators"); generators.setAccessible(true);
        out=new java.io.ByteArrayOutputStream();
        new java.io.ObjectOutputStream(out).writeObject(generators.get(null));
        System.out.println("RNG266 "+label+" "+Base64.getEncoder().encodeToString(out.toByteArray()));
    }
    private JSONObject state(String command) {
        Hero h=Dungeon.hero;
        JSONObject j=new JSONObject();
        j.put("command",command).put("time",Actor.now()).put("depth",Dungeon.depth).put("pos",h.pos)
                .put("HP",h.HP).put("HT",h.HT).put("shield",h.shielding()).put("level",h.lvl)
                .put("exp",h.exp).put("totalTime",Statistics.duration+Actor.now()).put("armor",h.belongings.armor().getClass().getSimpleName()+":+"+h.belongings.armor().level()).put("strength",h.STR()).put("hunger",h.buff(Hunger.class)==null?JSONObject.NULL:h.buff(Hunger.class).hunger());
        JSONArray inventory=new JSONArray();
        for(Item item:h.belongings) inventory.put(item.getClass().getSimpleName()+":"+item.quantity()+":+"+item.level());
        j.put("inventory",inventory);
        try {j.put("tomeCharge",charge(h.belongings.getItem(HolyTome.class)));Field partial=Artifact.class.getDeclaredField("partialCharge");partial.setAccessible(true);j.put("partialCharge",partial.getFloat(h.belongings.getItem(HolyTome.class)));}catch(Exception e){throw new RuntimeException(e);}
        JSONArray mobs=new JSONArray();
        for(Mob m:Dungeon.level.mobs) mobs.put(new JSONObject().put("class",m.getClass().getSimpleName()).put("id",m.id())
                .put("pos",m.pos).put("HP",m.HP).put("state",m.state.getClass().getSimpleName()).put("visible",Dungeon.level.heroFOV[m.pos])
                .put("magicCollision",new com.shatteredpixel.shatteredpixeldungeon.mechanics.Ballistica(h.pos,m.pos,com.shatteredpixel.shatteredpixeldungeon.mechanics.Ballistica.MAGIC_BOLT).collisionPos)
                .put("projectileCollision",new com.shatteredpixel.shatteredpixeldungeon.mechanics.Ballistica(h.pos,m.pos,com.shatteredpixel.shatteredpixeldungeon.mechanics.Ballistica.PROJECTILE).collisionPos));
        j.put("mobs",mobs);
        j.put("ironKeys",com.shatteredpixel.shatteredpixeldungeon.journal.Notes.keyCount(new com.shatteredpixel.shatteredpixeldungeon.items.keys.IronKey(Dungeon.depth)));
        j.put("goldenKeys",com.shatteredpixel.shatteredpixeldungeon.journal.Notes.keyCount(new com.shatteredpixel.shatteredpixeldungeon.items.keys.GoldenKey(Dungeon.depth)));
        JSONArray heaps=new JSONArray();
        for(Heap heap:Dungeon.level.heaps.valueList()){
            JSONArray items=new JSONArray();for(Item item:heap.items)items.put(item.getClass().getSimpleName()+":"+item.quantity()+":+"+item.level());
            heaps.put(new JSONObject().put("pos",heap.pos).put("type",heap.type).put("items",items));
        }
        j.put("heaps",heaps);
        return j;
    }
    private void log(String s) {
        assertEquals("Maximum HP must stay exactly one",1,Dungeon.hero.HT);assertTrue("Current HP exceeds one",Dungeon.hero.HP<=1);
        System.out.println("ROUTE "+state(s));
        JSONArray buffs=new JSONArray();
        for(Buff b:Dungeon.hero.buffs()){
            JSONObject entry=new JSONObject().put("type",b.getClass().getSimpleName()).put("remaining",b.cooldown());
            if(b instanceof ShieldOfLight.ShieldOfLightTracker)entry.put("target",((ShieldOfLight.ShieldOfLightTracker)b).object);
            buffs.put(entry);
        }
        System.out.println("BUFF_DETAIL "+s+" "+buffs);
        TimekeepersHourglass hourglass=Dungeon.hero.belongings.getItem(TimekeepersHourglass.class);
        if(hourglass!=null){
            try{Field whole=Artifact.class.getDeclaredField("charge"),part=Artifact.class.getDeclaredField("partialCharge");whole.setAccessible(true);part.setAccessible(true);
                System.out.println("HOURGLASS_DETAIL "+s+" charge="+whole.getInt(hourglass)+" partial="+part.getFloat(hourglass)+" equipped="+hourglass.isEquipped(Dungeon.hero)+" frozen="+(Dungeon.hero.buff(TimekeepersHourglass.timeFreeze.class)!=null));
            }catch(Exception e){throw new RuntimeException(e);}
        }
        if(Dungeon.depth==5){
            for(Mob m:Dungeon.level.mobs)if(m instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Goo){
                try{Field pumped=m.getClass().getDeclaredField("pumpedUp");pumped.setAccessible(true);System.out.println("GOO_DETAIL "+s+" HP="+m.HP+" pumped="+pumped.getInt(m)+" water="+Dungeon.level.water[m.pos]+" heroWater="+Dungeon.level.water[Dungeon.hero.pos]+" locked="+Dungeon.level.locked+" heroShield="+Dungeon.hero.shielding());}catch(Exception e){throw new RuntimeException(e);}
            }
        }
    }
    private void waitOne() { Dungeon.hero.rest(false); ready(); log("WAIT"); }
    private void click(int cell) { assertFalse("Script would attack passive exile at "+cell, Actor.findChar(cell) instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.GnollExile); assertTrue(Dungeon.hero.handle(cell)); Dungeon.hero.next(); Dungeon.hero.busy(); ready(); log("CLICK "+cell); }
    private void cast(ClericSpell spell, Integer target) {
        Hero h=Dungeon.hero; HolyTome t=h.belongings.getItem(HolyTome.class);
        assertTrue(t.canCast(h,spell));
        if(target!=null) assertTrue("Target must be in actual FOV",Dungeon.level.heroFOV[target]);
        selection=null; spell.onCast(t,h);
        if(target!=null){assertNotNull(selection);selection.onSelect(target);}
        ready(); log("CAST "+spell.getClass().getSimpleName()+" "+target);
    }
    private void throwItem(Class<? extends Item> type,int target) {
        Item item=Dungeon.hero.belongings.getItem(type); assertNotNull(item);
        assertTrue(Dungeon.level.heroFOV[target]);
        item.cast(Dungeon.hero,target); ready(); log("THROW "+type.getSimpleName()+" "+target);
    }
    private void upgradeOwnedSpear() throws Exception {
        Item scroll=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfUpgrade.class);
        Item spear=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class);
        assertNotNull(scroll);assertNotNull(spear);
        int oldLevel=spear.level();
        itemSelection=null;upgradeButton=null;
        scroll.execute(Dungeon.hero,"READ");assertNotNull(itemSelection);
        assertTrue(itemSelection.itemSelectable(spear));itemSelection.onSelect(spear);
        assertNotNull(upgradeButton);
        Method confirm=upgradeButton.getClass().getDeclaredMethod("onClick");confirm.setAccessible(true);confirm.invoke(upgradeButton);
        ready();log("READ OWNED UPGRADE ON OWNED SPEAR");
        assertEquals(oldLevel+1,spear.level());assertNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfUpgrade.class));
    }
    private void craftShieldingAtActualPot() throws Exception {
        assertTrue("Must enter alchemy using the actual station action",pendingAlchemy);
        assertTrue(Dungeon.level.distance(Dungeon.hero.pos,1495)<=1);
        assertEquals(Terrain.ALCHEMY,Dungeon.level.map[1495]);
        AlchemyScene scene=mock(AlchemyScene.class,CALLS_REAL_METHODS);
        String[] ui={"energyIcon","energyLeft","energyAdd","repeat","cancel","smokeEmitter","bubbleEmitter","sparkEmitter"};
        for(String name:ui){Field f=AlchemyScene.class.getDeclaredField(name);f.setAccessible(true);f.set(scene,mock(f.getType(),RETURNS_DEEP_STUBS));}
        String[] arrays={"inputs","combines","outputs"};Object[][] old=new Object[3][];
        for(int a=0;a<arrays.length;a++){
            Field f=AlchemyScene.class.getDeclaredField(arrays[a]);f.setAccessible(true);Object[] array=(Object[])f.get(null);old[a]=array.clone();
            for(int n=0;n<array.length;n++){
                Class<?> type=array.getClass().getComponentType();
                array[n]=mock(type,a==0?CALLS_REAL_METHODS:RETURNS_DEFAULTS);
                if(a==0){Field slot=type.getDeclaredField("slot");slot.setAccessible(true);slot.set(array[n],mock(com.shatteredpixel.shatteredpixeldungeon.ui.ItemSlot.class));}
            }
        }
        try{
            Item healing=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfHealing.class);assertNotNull(healing);
            ArrayList<Item> selected=new ArrayList<>();selected.add(healing.duplicate());
            scene.populate(selected,Dungeon.hero.belongings); //original inventory detachment and recipe selection
            Method filter=AlchemyScene.class.getDeclaredMethod("filterInput",Class.class);filter.setAccessible(true);
            ArrayList<Item> inputs=(ArrayList<Item>)filter.invoke(scene,Item.class);
            ArrayList<Recipe> recipes=Recipe.findRecipes(inputs);int selectedRecipe=-1;
            for(int n=0;n<recipes.size();n++)if(recipes.get(n).sampleOutput(inputs) instanceof com.shatteredpixel.shatteredpixeldungeon.items.potions.exotic.PotionOfShielding)selectedRecipe=n;
            assertTrue("No shielding recipe: inputs="+inputs+" identified="+(inputs.isEmpty()?"empty":inputs.get(0).isIdentified())+" recipeCount="+recipes.size(),selectedRecipe>=0);int cost=recipes.get(selectedRecipe).cost(inputs),energyBefore=Dungeon.energy;
            assertTrue("Actual energy must cover the recipe",cost<=energyBefore);
            Method combine=AlchemyScene.class.getDeclaredMethod("combine",int.class);combine.setAccessible(true);combine.invoke(scene,selectedRecipe);
            assertEquals(energyBefore-cost,Dungeon.energy);
            assertNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfHealing.class));
            assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.exotic.PotionOfShielding.class));
            log("CRAFT SHIELDING USING OWNED HEALING AND EARNED ENERGY");
        }finally{
            for(int a=0;a<arrays.length;a++){Field f=AlchemyScene.class.getDeclaredField(arrays[a]);f.setAccessible(true);Object[] array=(Object[])f.get(null);System.arraycopy(old[a],0,array,0,array.length);}
            pendingAlchemy=false;currentTestScene=gameplaySceneStub;
        }
    }
    private void throwLitBomb(int target) {
        Item bomb=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.bombs.Bomb.class);
        assertNotNull(bomb);selection=null;bomb.execute(Dungeon.hero,"LIGHTTHROW");
        assertNotNull(selection);selection.onSelect(target);ready();log("LIGHTTHROW Bomb "+target);
    }
    @Test public void seed266InitialCommands() throws Exception {
        System.out.println("RUNNER_STAGE scheduler start");
        ready();
        if(System.getProperty("route.resume")!=null){verifyCheckpoint(System.getProperty("route.resume"));if(Dungeon.depth==3)thirdFloorSection();else if(Dungeon.depth==4){if(Dungeon.hero.pos==826)returnedFourthFloorSection();else if(Dungeon.hero.pos==437)purityCheckpointSection();else if(Dungeon.hero.pos==1035)foodCheckpointSection();else fourthFloorSection();}else if(Dungeon.depth==5){if(Boolean.getBoolean("route.postGoo"))postGooSection();else if(Boolean.getBoolean("route.armoredGoo"))armoredGooSection();else fifthFloorSection();}else if(Dungeon.depth==6)sixthFloorSection();else if(Dungeon.depth==7)seventhFloorSection();else if(Dungeon.depth==8)eighthFloorSection();else if(Dungeon.depth==9)ninthFloorSection();else fail("Unwritten section");verifyExpectedEnd();return;}
        assertEquals(1,Dungeon.hero.lvl); assertEquals(1,Dungeon.hero.HP); assertEquals(1,Dungeon.hero.HT);
        for(Map<Talent,Integer> tier:Dungeon.hero.talents) for(int value:tier.values()) assertEquals(0,value);
        JSONObject layout=new JSONObject(); Level l=Dungeon.level;
        layout.put("width",l.width()).put("height",l.height()).put("entrance",l.entrance()).put("exit",l.exit())
                .put("terrain",new JSONArray(l.map));
        JSONArray heaps=new JSONArray();
        for(Heap hp:l.heaps.valueList()){
            JSONArray its=new JSONArray();for(Item item:hp.items)its.put(item.getClass().getSimpleName()+":"+item.quantity()+":+"+item.level()+":cursed="+item.cursed);
            heaps.put(new JSONObject().put("pos",hp.pos).put("type",hp.type.toString()).put("items",its));
        }
        layout.put("heaps",heaps);
        JSONArray traps=new JSONArray();for(com.shatteredpixel.shatteredpixeldungeon.levels.traps.Trap trap:l.traps.valueList())
            traps.put(new JSONObject().put("class",trap.getClass().getSimpleName()).put("pos",trap.pos).put("visible",trap.visible));
        layout.put("traps",traps);
        System.out.println("LAYOUT266 "+layout); log("START"); snapshot("START");
        waitOne(); waitOne();
        snapshot("AFTER_TWO_WAITS");
        //Literal exploratory prefix. No path planner, policy, free item collection or resource injection.
        for(int cell:new int[]{905,906,907,908,909,910,911,912,951,952,953,954,955,956,957,958,
                959,960,999,1038,1077,1078,1079,1080,1119}) click(cell);
        snapshot("KEY_ROOM_PREFIX");
        for(int cell:new int[]{1080,1079,1078,1077,1038,999,960,959,958,957,956,955,954,953,
                952,951,912,911,910,909,908,868,830,831,832,833,834,834,795,796,797,758,719}) click(cell);
        assertNotNull("Mail must actually have been picked up",Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.armor.MailArmor.class));
        snapshot("MAIL_ACQUIRED");
        click(757); //Take the actual bomb in the same room.
        for(int cell:new int[]{796,834,833,832,831,830,868,908,909,910,911,912,951,952,953,954,
                955,956,957,958,959,960,999,1038,1077,1078,1079,1080,1081,1082}) click(cell);
        snapshot("FIRST_RAT_APPROACH");
        cast(GuidingLight.INSTANCE,965);
        snapshot("FIRST_RAT_FIRST_LIGHT");
        for(int cell:new int[]{1044,1006,967,968,1007,1007,969,970,971,932,893,854,815,776,737,736,735,734,
                695,656,655,654,653}) click(cell);
        snapshot("FIRST_SNAKE_APPROACH");
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,649);
        snapshot("FIRST_SNAKE_KILLED");
        for(int cell:new int[]{652,651,650,649,610,571,532,493,454,453,452}) click(cell);
        for(int n=0;n<10;n++) waitOne();
        cast(HolyWard.INSTANCE,null);
        click(451);
        snapshot("UPPER_RAT_APPROACH");
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,410);
        snapshot("UPPER_RAT_FIRST_SPEAR");
        if(Boolean.getBoolean("route.badApproach")) {
            for(int cell:new int[]{450,449,410,372,333,332,331,330,329}) click(cell);
            return;
        }
        click(450);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,325);
        for(int cell:new int[]{449,410,372}) click(cell);
        cast(GuidingLight.INSTANCE,442);
        click(333);
        waitOne(); waitOne();
        snapshot("SECOND_SNAKE_APPROACH");
        cast(GuidingLight.INSTANCE,406);
        snapshot("CENTER_RAT_HIT");
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,407);
        for(int cell:new int[]{371,409,408,407,367,327,326,325,364,403,442,441}) click(cell);
        for(int n=0;n<135;n++)waitOne();
        snapshot("LEFT_DOOR_APPROACH");
        click(440);
        snapshot("LEFT_RATS_VISIBLE");
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,476);
        snapshot("LEFT_RAT_FIRST_HIT");
        throwLitBomb(439);
        click(441);click(442);
        snapshot("LEFT_RATS_BOMB_RESOLVED");
        click(441);
        //Explicit hand-written branches for the observed bomb variants. No route search or combat policy.
        if(Dungeon.hero.exp==8){
            if(Actor.findChar(439)!=null){
                cast(GuidingLight.INSTANCE,439);
                if(Actor.findChar(440)!=null)throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,440);
            }else{
                for(int cell:new int[]{480,519,558,597,596,595,594,555})click(cell);
                assertNotNull("Uninvestigated lower-rat timing",Actor.findChar(515));
                cast(HolyWard.INSTANCE,null);
                cast(GuidingLight.INSTANCE,515);
                if(Actor.findChar(515)!=null)throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,515);
                assertEquals("Lower rat did not die",9,Dungeon.hero.exp);
                for(int cell:new int[]{594,595,596,597,558,519,480,441})click(cell);
            }
        }
        assertEquals(9,Dungeon.hero.exp);
        for(int cell:new int[]{440,440}) click(cell);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,277);
        if(Dungeon.hero.lvl==1){
            for(int cell:new int[]{439,400})click(cell);
            assertNotNull("Uninvestigated bridge-rat timing",Actor.findChar(318));
            cast(GuidingLight.INSTANCE,318);
        }
        assertEquals(2,Dungeon.hero.lvl);assertEquals(1,Dungeon.hero.talentPointsAvailable(1));
        Dungeon.hero.upgradeTalent(Talent.SHIELD_OF_LIGHT);log("UPGRADE SHIELD_OF_LIGHT");
        Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.Food.class).execute(Dungeon.hero,"EAT");ready();log("EAT FIRST RATION ON CLEARED FLOOR ONE");
        if(Dungeon.hero.belongings.getItem(HolyTome.class).level()==0)cast(HolyWard.INSTANCE,null);
        assertEquals(1,Dungeon.hero.belongings.getItem(HolyTome.class).level());
        for(int n=0;n<180;n++)waitOne();
        assertEquals(4,charge(Dungeon.hero.belongings.getItem(HolyTome.class)));
        for(int cell:new int[]{439,439,400,361,322,321,282,281,242,241,240,239,277,
                239,240,241,242,281,282,321,322,361,400,439,440,441,442,403,364,325,326,327,328,329,330,331,332,333,372,410,410,449,450,451,452,453,454,493,494,495})click(cell);
        assertEquals(2,Dungeon.depth);
        System.out.println("FLOOR_LAYOUT "+new JSONObject().put("depth",Dungeon.depth).put("width",Dungeon.level.width()).put("height",Dungeon.level.height()).put("terrain",new JSONArray(Dungeon.level.map)).put("entrance",Dungeon.level.entrance()).put("exit",Dungeon.level.exit()));
        log("FLOOR_TWO_ENTERED");
        for(int cell:new int[]{1333,1375,1417,1459,1458,1457,1456,1455,1454,1453,1452,1451,1450,1492,1534,1576,1575,1574,1573,1531,1489,1447})click(cell);
        log("STRENGTH_ACQUIRED");
        Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfStrength.class).execute(Dungeon.hero,"DRINK");ready();log("DRINK STRENGTH");
        click(1405);
        cast(GuidingLight.INSTANCE,1359);
        log("SECOND_FLOOR_RAT_HIT");
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,1360);
        for(int cell:new int[]{1363,1321,1320,1319,1318,1317,1316,1315,1357,1399,1441,1483})click(cell);
        log("UPGRADE_AND_KEY_ACQUIRED");
        for(int cell:new int[]{1441,1399,1357,1358,1359,1360})click(cell);
        log("RECOVER SECOND FLOOR SPEAR");
        upgradeOwnedSpear();
        Mob roomGnoll=(Mob)Actor.findChar(939);assertNotNull(roomGnoll);
        Mob roomRat=(Mob)Actor.findChar(848);assertNotNull(roomRat);
        for(int cell:new int[]{1317,1316,1315,1273,1231,1189,1147,1105,1104,1062,1020})click(cell);
        if(Boolean.getBoolean("route.encumberedMail")){
            Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.armor.MailArmor.class).execute(Dungeon.hero,"EQUIP");Dungeon.hero.busy();ready();log("EQUIP MAIL FOR GNOLL");
        }
        click(978);
        log("GNOLL_APPROACH");
        cast(GuidingLight.INSTANCE,roomRat.pos);
        if(roomRat.isAlive())throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,roomRat.pos);
        if(roomRat.isAlive())throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,roomRat.pos);
        assertFalse("Upper rat not cleared",roomRat.isAlive());
        if(!Dungeon.level.heroFOV[roomGnoll.pos])click(936);
        if(!Dungeon.level.heroFOV[roomGnoll.pos])waitOne();
        assertTrue("Gnoll not revealed by investigated approach",Dungeon.level.heroFOV[roomGnoll.pos]);
        cast(ShieldOfLight.INSTANCE,roomGnoll.pos);
        cast(GuidingLight.INSTANCE,roomGnoll.pos);
        log("GNOLL_SHIELDED_EXCHANGE");
        if(roomGnoll.isAlive())throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,roomGnoll.pos);
        log("GNOLL_FIRST_SPEAR");
        if(roomGnoll.isAlive())throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,roomGnoll.pos);
        if(roomGnoll.isAlive())click(roomGnoll.pos);
        assertFalse("First gnoll not cleared",roomGnoll.isAlive());
        log("FIRST_GNOLL_KILLED");
        for(int cell:new int[]{937,937,896,855,813,771,729,728,727})click(cell);
        log("PASTY_AND_EXIT_APPROACH");
        if(Boolean.getBoolean("route.certifyPrefix")){
            Mob extraSnake=Dungeon.level.mobs.stream().filter(m->m.id()==44).findFirst().get();
            cast(GuidingLight.INSTANCE,extraSnake.pos);log("CERTIFIED PREFIX HANDLE EXTRA SNAKE AT RANGE TWO");
            assertFalse(extraSnake.isAlive());
        }
        for(int cell:new int[]{685,643,601,600,599,598,640,682,724})click(cell);
        log("SECOND_FLOOR_EXIT");
        assertEquals(3,Dungeon.depth);
        System.out.println("FLOOR_LAYOUT "+new JSONObject().put("depth",Dungeon.depth).put("width",Dungeon.level.width()).put("height",Dungeon.level.height()).put("terrain",new JSONArray(Dungeon.level.map)).put("entrance",Dungeon.level.entrance()).put("exit",Dungeon.level.exit()));
        log("FLOOR_THREE_ENTERED");
        if(System.getProperty("route.checkpointOut")!=null)writeCheckpoint(System.getProperty("route.checkpointOut"));
        if(Boolean.getBoolean("route.stopAfterFloor3")){verifyExpectedEnd();return;}
        thirdFloorSection();
    }
    private void thirdFloorSection() throws Exception {
        assertEquals(3,Dungeon.depth);
        Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.Food.class).execute(Dungeon.hero,"EAT");ready();log("EAT SECOND RATION");
        Mob firstBridgeGnoll=(Mob)Actor.findChar(455);assertNotNull(firstBridgeGnoll);
        Mob secondBridgeGnoll=(Mob)Actor.findChar(412);assertNotNull(secondBridgeGnoll);
        for(int n=0;n<Integer.getInteger("route.initial3Recharge",60);n++)waitOne();
        for(int cell:new int[]{684,683,682,681,680,679,678,677,676,675,675})click(cell);
        assertNotNull("Scroll must actually be picked up",Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfUpgrade.class));
        upgradeOwnedSpear();
        Mob frontBridgeGnoll=(Mob)Actor.findChar(new com.shatteredpixel.shatteredpixeldungeon.mechanics.Ballistica(Dungeon.hero.pos,firstBridgeGnoll.pos,com.shatteredpixel.shatteredpixeldungeon.mechanics.Ballistica.MAGIC_BOLT).collisionPos);
        assertNotNull("Bridge projectile has no enemy target",frontBridgeGnoll);
        cast(ShieldOfLight.INSTANCE,frontBridgeGnoll.pos);
        cast(GuidingLight.INSTANCE,frontBridgeGnoll.pos);
        if(frontBridgeGnoll.isAlive())throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,frontBridgeGnoll.pos);
        if(frontBridgeGnoll.isAlive())throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,frontBridgeGnoll.pos);
        assertFalse("First bridge gnoll not cleared",frontBridgeGnoll.isAlive());
        log("FIRST_BRIDGE_GNOLL_KILLED");
        Mob rearBridgeGnoll=frontBridgeGnoll==firstBridgeGnoll?secondBridgeGnoll:firstBridgeGnoll;
        cast(GuidingLight.INSTANCE,rearBridgeGnoll.pos);
        if(rearBridgeGnoll.isAlive())throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,rearBridgeGnoll.pos);
        if(rearBridgeGnoll.isAlive())throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,rearBridgeGnoll.pos);
        assertFalse("Second bridge gnoll not cleared",rearBridgeGnoll.isAlive());
        log("BOTH_BRIDGE_GNOLLS_KILLED");
        for(int cell:new int[]{631,631,587,543,542,541,541,584,627,626,625,624,623,622,621,620,619,618,575,532,489,446,403})click(cell);
        Dungeon.hero.search(true);ready();log("SEARCH SECRET DOOR 402");
        click(402);log("SECRET_ROOM_ENTRY");
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,358);
        log("SECRET_ROOM_RAT_SHOT");
        for(int cell:new int[]{358,357,356,355,354,397,396,439,482,525,526,527,527,528,529,529})click(cell);
        assertNotNull("Levitation must actually be collected",Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfLevitation.class));
        log("LEVITATION_ACTUALLY_ACQUIRED");
        for(int cell:new int[]{528,527,526,525,482,439,396,397,398,399,400,401,402,403,446,489,532,575,618,619,620,621,622,623,624,625,626,627,670,671,672,673,674,675})click(cell);
        Mob vaultGnoll=(Mob)Actor.findChar(804);assertNotNull("Uninvestigated vault gnoll position",vaultGnoll);
        cast(ShieldOfLight.INSTANCE,vaultGnoll.pos);cast(GuidingLight.INSTANCE,vaultGnoll.pos);
        if(vaultGnoll.isAlive())throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,vaultGnoll.pos);
        if(vaultGnoll.isAlive())throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,vaultGnoll.pos);
        assertFalse("Spawned vault gnoll survived",vaultGnoll.isAlive());
        for(int cell:new int[]{717,717,760,760,759,758,757,756,798,841,884})click(cell);
        log("CHASM_VAULT_APPROACH");
        assertEquals(841,Dungeon.hero.pos);
        Dungeon.hero.search(true);ready();log("SEARCH SECRET VAULT DOOR 884");
        click(884);assertEquals(884,Dungeon.hero.pos);
        assertTrue("Earned golden key required",com.shatteredpixel.shatteredpixeldungeon.journal.Notes.keyCount(new com.shatteredpixel.shatteredpixeldungeon.items.keys.GoldenKey(3))>=1);
        Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfLevitation.class).execute(Dungeon.hero,"DRINK");ready();log("DRINK OWNED LEVITATION");
        for(int cell:new int[]{927,970,1012,1012})click(cell);
        com.shatteredpixel.shatteredpixeldungeon.items.weapon.melee.Quarterstaff staff=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.melee.Quarterstaff.class);
        assertNotNull("Quarterstaff must actually be collected",staff);assertEquals(2,staff.level());assertTrue(staff.STRReq()<=Dungeon.hero.STR());
        staff.execute(Dungeon.hero,"EQUIP");Dungeon.hero.busy();ready();log("EQUIP EARNED QUARTERSTAFF");
        for(int cell:new int[]{970,927,884,841})click(cell);
        assertEquals(841,Dungeon.hero.pos);assertFalse("Must return to solid ground",Dungeon.level.pit[Dungeon.hero.pos]);
        log("VAULT_STAFF_ACQUIRED_AND_ESCAPED");
        for(int cell:new int[]{798,756,757,758,759,760,803,846,847})click(cell);
        for(int n=0;n<6;n++)waitOne();
        Mob bottomSnake=(Mob)Actor.findChar(975);assertNotNull(bottomSnake);
        click(890);log("SNAKE_ROOM_APPROACH");
        cast(GuidingLight.INSTANCE,bottomSnake.pos);
        if(bottomSnake.isAlive())throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,bottomSnake.pos);
        assertFalse(bottomSnake.isAlive());log("BOTTOM_SNAKE_KILLED");
        Mob bottomRat=(Mob)Actor.findChar(1195);assertNotNull(bottomRat);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,bottomRat.pos);
        if(bottomRat.isAlive())throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,bottomRat.pos);
        assertFalse(bottomRat.isAlive());log("BOTTOM_RAT_KILLED");
        for(int cell:new int[]{933,976,1019,1020,1064,1108,1151,1194,1195,1195,1194,1237,1237,1280,1323,1324,1325,1325,1326,1327,1327})click(cell);
        assertNotNull("Second strength potion must be collected",Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfStrength.class));
        assertEquals("Actual energy crystal collection",5,Dungeon.energy);
        log("STRENGTH_AND_ALCHEMY_ENERGY_ACQUIRED");
        Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfStrength.class).execute(Dungeon.hero,"DRINK");ready();log("DRINK SECOND STRENGTH");
        assertEquals(12,Dungeon.hero.STR());
        for(int cell:new int[]{1369,1411,1453,1495})click(cell);
        craftShieldingAtActualPot();
        log("ALCHEMY_COMPLETE");
        click(1409);click(1366);
        if(Boolean.getBoolean("route.preemptiveShield")){
            Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.exotic.PotionOfShielding.class).execute(Dungeon.hero,"DRINK");ready();log("DRINK OWNED SHIELDING BEFORE EXIT");
        }
        click(1323);click(1280);
        log("ALCHEMY_ROOM_EXIT_APPROACH");
        for(int n=0;n<10;n++)waitOne();
        click(1237);log("OPEN ALCHEMY EXIT AFTER PAID WAIT");
        click(1194);click(1151);log("LEAVE ALCHEMY CORRIDOR");
        for(int cell:new int[]{1108,1064,1020,1019,976,933,890,847,846,803,760,759,716,673,672,671,670,627,626,625})click(cell);
        Mob corridorSnake=(Mob)Actor.findChar(623);assertNotNull("Uninvestigated corridor snake position",corridorSnake);
        cast(GuidingLight.INSTANCE,corridorSnake.pos);
        if(corridorSnake.isAlive())click(corridorSnake.pos);
        assertFalse(corridorSnake.isAlive());
        assertEquals(3,Dungeon.hero.lvl);assertEquals(1,Dungeon.hero.talentPointsAvailable(1));
        Dungeon.hero.upgradeTalent(Talent.SHIELD_OF_LIGHT);log("EARN SECOND SHIELD_OF_LIGHT POINT");
        for(int cell:new int[]{624,623,622,621,620,619,618,617,616,615,614,613,612,611,654})click(cell);
        log("CRAB_ROOM_OUTSIDE_CLOSED_DOOR");
        Mob pursuingSwarm=(Mob)Actor.findChar(613);assertNotNull("Uninvestigated pursuing swarm position",pursuingSwarm);
        cast(ShieldOfLight.INSTANCE,pursuingSwarm.pos);
        Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.exotic.PotionOfShielding.class).execute(Dungeon.hero,"DRINK");ready();log("DRINK OWNED SHIELDING FOR PURSUING SWARM");
        click(pursuingSwarm.pos);log("SWARM_FIRST_REAL_MELEE");
        if(pursuingSwarm.isAlive())click(pursuingSwarm.pos);
        if(pursuingSwarm.isAlive())click(pursuingSwarm.pos);
        log("SWARM_PARENT_THREE_EXCHANGES");
        if(pursuingSwarm.isAlive())click(pursuingSwarm.pos);
        assertFalse("Swarm parent survived four attacks",pursuingSwarm.isAlive());
        Mob smallSwarm=(Mob)Actor.findChar(611);assertNotNull(smallSwarm);
        click(smallSwarm.pos);if(smallSwarm.isAlive())click(smallSwarm.pos);
        assertFalse("Small swarm child survived",smallSwarm.isAlive());
        log("SWARM_PARENT_AND_SMALL_CHILD_KILLED");
        Mob largeSwarm=(Mob)Actor.findChar(655);assertNotNull(largeSwarm);
        click(largeSwarm.pos);if(largeSwarm.isAlive())click(largeSwarm.pos);
        log("LARGE_SWARM_CHILD_TWO_EXCHANGES");
        if(largeSwarm.isAlive())click(largeSwarm.pos);assertFalse(largeSwarm.isAlive());
        Mob finalSwarm=(Mob)Actor.findChar(655);assertNotNull(finalSwarm);
        click(finalSwarm.pos);if(finalSwarm.isAlive())click(finalSwarm.pos);
        assertFalse(finalSwarm.isAlive());log("PURSUING_SWARM_AND_ALL_CHILDREN_DEFEATED");
        for(int n=0;n<Integer.getInteger("route.exitRecharge",28);n++)waitOne();
        click(653);log("CRAB_ACTUALLY_REVEALED");
        waitOne();log("CRAB_LURE_WAIT_FROM_DOOR");
        Mob exitCrab=(Mob)Actor.findChar(564);assertNotNull(exitCrab);
        cast(ShieldOfLight.INSTANCE,exitCrab.pos);
        waitOne();log("CRAB_LURED_AROUND_OBSTACLE");
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,exitCrab.pos);
        if(exitCrab.isAlive())throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear.class,exitCrab.pos);
        log("CRAB_TWO_RANGED_ATTACKS");
        if(exitCrab.isAlive())click(exitCrab.pos);
        if(exitCrab.isAlive())click(exitCrab.pos);
        assertFalse(exitCrab.isAlive());log("EXIT_CRAB_DEFEATED");
        for(int cell:new int[]{652,651,650,649})click(cell);
        log("BLINK_EXIT_LINE");
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.stones.StoneOfBlink.class,520);
        assertEquals(520,Dungeon.hero.pos);log("BLINK_ONTO_REAL_EXIT");
        click(520);assertEquals(4,Dungeon.depth);log("FLOOR_FOUR_ENTERED");
        System.out.println("FLOOR_LAYOUT "+new JSONObject().put("depth",Dungeon.depth).put("width",Dungeon.level.width()).put("height",Dungeon.level.height()).put("terrain",new JSONArray(Dungeon.level.map)).put("entrance",Dungeon.level.entrance()).put("exit",Dungeon.level.exit()));
        if(System.getProperty("route.checkpoint4Out")!=null)writeCheckpoint(System.getProperty("route.checkpoint4Out"));

        assertEquals(1,Dungeon.hero.HP);
    }
    private void fourthFloorSection() throws Exception {
        assertEquals(4,Dungeon.depth);assertEquals(1007,Dungeon.hero.pos);
        System.out.println("FLOOR_LAYOUT "+new JSONObject().put("depth",4).put("width",Dungeon.level.width()).put("height",Dungeon.level.height()).put("terrain",new JSONArray(Dungeon.level.map)).put("entrance",Dungeon.level.entrance()).put("exit",Dungeon.level.exit()));
        for(com.shatteredpixel.shatteredpixeldungeon.levels.traps.Trap t:Dungeon.level.traps.valueList())System.out.println("FLOOR_FOUR_TRAP "+t.pos+" "+t.getClass().getSimpleName());
        Item pasty=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.Pasty.class);assertNotNull(pasty);
        pasty.execute(Dungeon.hero,"EAT");ready();log("EAT EARNED PASTY ON FLOOR FOUR");
        for(int n=0;n<120;n++)waitOne();
        log("FLOOR_FOUR_BOUNDED_RECHARGE");
        for(int c:new int[]{968,929,890,889,888})click(c);
        Mob entranceCrab=Dungeon.level.mobs.stream().filter(m->m.id()==81).findFirst().get();
        cast(ShieldOfLight.INSTANCE,entranceCrab.pos);if(!Boolean.getBoolean("route.crabNoLight"))cast(GuidingLight.INSTANCE,entranceCrab.pos);
        for(int n=0;n<3 && entranceCrab.isAlive();n++)click(entranceCrab.pos);
        assertFalse(entranceCrab.isAlive());log("FLOOR_FOUR_CRAB_DEFEATED");
        for(int c:new int[]{887,848,809})click(c);
        Mob approachSlime=Dungeon.level.mobs.stream().filter(m->m.id()==87).findFirst().get();
        cast(ShieldOfLight.INSTANCE,approachSlime.pos);
        for(int n=0;n<4 && approachSlime.isAlive();n++)click(approachSlime.pos);
        if(approachSlime.isAlive() && Boolean.getBoolean("route.crabNoLight")){
            cast(HolyWard.INSTANCE,null);
            for(int n=0;n<2 && approachSlime.isAlive();n++)click(approachSlime.pos);
        }
        assertFalse(approachSlime.isAlive());log("FLOOR_FOUR_SPAWNED_SLIME_DEFEATED");
        for(int n=0;n<Integer.getInteger("route.mid4Recharge",20);n++)waitOne();
        for(int c:new int[]{808,807,806})click(c);
        Mob northGnoll=Dungeon.level.mobs.stream().filter(m->m.id()==82).findFirst().get();
        if(!Dungeon.level.adjacent(Dungeon.hero.pos,northGnoll.pos))click(806);
        click(northGnoll.pos);
        assertFalse(Dungeon.level.mobs.stream().anyMatch(m->m.id()==82));log("FLOOR_FOUR_GNOLL_DEFEATED");
        for(int c:new int[]{767,728,689,650,611,610,609,608,607,606,605,604,603})click(c);
        if(Boolean.getBoolean("route.earlyWard"))cast(HolyWard.INSTANCE,null);
        for(int c:(Boolean.getBoolean("route.diagonalCorner")?new int[]{563,524,484}:new int[]{563,524,485,484}))click(c);
        for(int c:new int[]{483,482,481,480,479,478,477,476,475,474,474})click(c);
        Mob northSwarm=Dungeon.level.mobs.stream().filter(m->m.id()==80).findFirst().get();
        boolean retainFlame=Boolean.getBoolean("route.retainFlame");
        if(retainFlame){if(Dungeon.hero.buff(HolyWard.HolyArmBuff.class)==null)cast(HolyWard.INSTANCE,null);}else cast(ShieldOfLight.INSTANCE,northSwarm.pos);
        click(473);
        if(retainFlame)waitOne();else throwItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfLiquidFlame.class,436);
        click(472);click(472);
        if(retainFlame)cast(GuidingLight.INSTANCE,northSwarm.pos);else cast(HolyWard.INSTANCE,null);
        click(472);
        assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class));
        click(northSwarm.pos);
        Mob child=Dungeon.level.mobs.stream().filter(m->m instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Swarm && m!=northSwarm).findFirst().get();
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,northSwarm.pos);
        click(child.pos);
        log("FLOOR_FOUR_SWARM_EXCHANGES");
        if(retainFlame){
            for(int n=0;n<2 && northSwarm.isAlive();n++)click(northSwarm.pos);
            for(int n=0;n<2 && child.isAlive();n++)click(child.pos);
            log("FLOOR_FOUR_RETAIN_FLAME_EXTRA_EXCHANGES");
        }
        assertFalse(Dungeon.level.mobs.stream().anyMatch(m->m instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Swarm));
        assertEquals(4,Dungeon.hero.lvl);assertEquals(1,Dungeon.hero.talentPointsAvailable(1));
        Dungeon.hero.upgradeTalent(Talent.SEARING_LIGHT);log("EARN FIRST SEARING_LIGHT POINT");
        if(System.getProperty("route.checkpointNorthOut")!=null)writeCheckpoint(System.getProperty("route.checkpointNorthOut"));
        if(retainFlame && Boolean.getBoolean("route.toGoo")){
            for(int c:new int[]{473,473,473,513,513})click(c);
            assertEquals(5,Dungeon.depth);log("FLOOR_FIVE_EARNED_ENTRY");
            System.out.println("FLOOR_LAYOUT "+new JSONObject().put("depth",5).put("width",Dungeon.level.width()).put("height",Dungeon.level.height()).put("terrain",new JSONArray(Dungeon.level.map)).put("entrance",Dungeon.level.entrance()).put("exit",Dungeon.level.exit()));
            if(System.getProperty("route.checkpoint5Out")!=null)writeCheckpoint(System.getProperty("route.checkpoint5Out"));
            return;
        }
        if(retainFlame){
            for(int c:new int[]{473,473,473,514,554,555,594,633,672})click(c);
            
            log("FLOOR_FOUR_BARRICADE_APPROACH_WITH_FLAME");
            Mob secondSlime=Dungeon.level.mobs.stream().filter(m->m.id()==92).findFirst().get();
            if(charge(Dungeon.hero.belongings.getItem(HolyTome.class))>=1)cast(ShieldOfLight.INSTANCE,secondSlime.pos);
            for(int n=0;n<4 && secondSlime.isAlive();n++)click(secondSlime.pos);
            assertFalse(secondSlime.isAlive());log("FLOOR_FOUR_SECOND_SPAWNED_SLIME_DEFEATED");
        }
    }

    private void fifthFloorSection() throws Exception {
        assertEquals(5,Dungeon.depth);assertEquals(708,Dungeon.hero.pos);
        for(int n=0;n<Integer.getInteger("route.gooPrep",100);n++)waitOne();
        if(Boolean.getBoolean("route.returnToFour")){
            click(708);assertEquals(4,Dungeon.depth);log("RETURN FLOOR FOUR AFTER PAID BOSS_FLOOR_RECHARGE");
            Mob returnSlime=Dungeon.level.mobs.stream().filter(m->m.id()==92).findFirst().get();
            cast(HolyWard.INSTANCE,null);cast(GuidingLight.INSTANCE,returnSlime.pos);
            waitOne();cast(ShieldOfLight.INSTANCE,returnSlime.pos);waitOne();
            for(int n=0;n<3 && returnSlime.isAlive();n++)click(returnSlime.pos);
            assertFalse(returnSlime.isAlive());log("RETURNING CLERIC DEFEATS SECOND SLIME WITH EARNED CHARGES");
            click(514);
            Mob ghost=Dungeon.level.mobs.stream().filter(m->m instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.Ghost).findFirst().get();
            assertTrue(Dungeon.level.adjacent(Dungeon.hero.pos,ghost.pos));click(ghost.pos);
            assertTrue(com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.Ghost.Quest.active());log("ACCEPT REAL GHOST QUEST");
            for(int c:new int[]{515,555,594,633,672,710,709})click(c);
            throwItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfLiquidFlame.class,707);
            for(int n=0;n<7;n++)waitOne();
            assertFalse(Dungeon.level.map[746]==Terrain.BARRICADE);
            assertEquals(0,com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Blob.volumeAt(746,com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Fire.class));
            for(int c:new int[]{708,707,746,785,784,784,823,822,821,821})click(c);
            assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.Food.class));
            assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfUpgrade.class));
            log("FLOOR FOUR BARRICADE FOOD AND UPGRADE ACTUALLY ACQUIRED");
            Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.Food.class).execute(Dungeon.hero,"EAT");ready();log("EAT LEGALLY ACQUIRED BARRICADE RATION");
            for(int c:new int[]{860,899,900,901,902,902,903,864,825,826,826})click(c);
            assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfToxicGas.class));
            log("BARRICADE ROOM GAS POTION AND GOLD ACQUIRED");
            if(System.getProperty("route.checkpointReturnOut")!=null)writeCheckpoint(System.getProperty("route.checkpointReturnOut"));
            return;
        }
        for(int c:new int[]{673,672,637})click(c);
        Dungeon.hero.search(true);ready();log("SEARCH FLOOR FIVE SECRET ENTRANCE");
        assertEquals(Terrain.DOOR,Dungeon.level.map[603]);
        for(int c:new int[]{603,569,535,501,500,499,465,431,430})click(c);
        log("GOO_EARNED_APPROACH");
        Mob goo=Dungeon.level.mobs.stream().filter(m->m instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Goo).findFirst().get();
        cast(GuidingLight.INSTANCE,goo.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,goo.pos);
        for(int c:new int[]{431,465,499,500,501,535,569,603,637})click(c);
        log("GOO_FIRST_OUTER_RETREAT");
    }

    private void returnedFourthFloorSection() throws Exception {
        assertEquals(4,Dungeon.depth);assertEquals(826,Dungeon.hero.pos);
        Mob pursuingCrab=Dungeon.level.mobs.stream().filter(m->m.id()==99).findFirst().get();
        cast(ShieldOfLight.INSTANCE,pursuingCrab.pos);
        for(int n=0;n<3 && pursuingCrab.isAlive();n++)click(pursuingCrab.pos);
        assertFalse(pursuingCrab.isAlive());log("RETURN ROUTE PURSUING CRAB DEFEATED");
        for(int c:new int[]{825,824,823,784,785,746,707,708,709,710,672,633,594,555,516,477,438,437,437,437})click(c);
        assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfPurity.class));
        log("RETURN ROUTE PURITY POTION ACQUIRED");
        if(System.getProperty("route.checkpointPurityOut")!=null)writeCheckpoint(System.getProperty("route.checkpointPurityOut"));
        if(Boolean.getBoolean("route.stopAtPurity"))return;
        Mob questCrab=Dungeon.level.mobs.stream().filter(m->m instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.GreatCrab).findFirst().get();
        cast(ShieldOfLight.INSTANCE,questCrab.pos);
        Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfPurity.class).execute(Dungeon.hero,"DRINK");ready();log("DRINK OWNED PURITY BEFORE QUEST GAS");
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfToxicGas.class,questCrab.pos);
        for(int c:new int[]{436,435,434,472,512,552})click(c);
        log("GREAT CRAB FIRST GAS KITE");
        for(int c:new int[]{553,554,555,556,517,478})click(c);
        log("GREAT CRAB GAS ESCAPE");
    }

    private void purityCheckpointSection() throws Exception {
        assertEquals(437,Dungeon.hero.pos);assertEquals(4,Dungeon.depth);
        log("EARNED PURITY CHECKPOINT READY FOR NEXT EXPERIMENT");
        for(int c:new int[]{436,435,434,472,512,552,553,554,555,594,633,672,673,674,675,676})click(c);
        log("GREAT CRAB LURED THROUGH CENTRAL ROOM WITHOUT SPENDING GAS");
        Mob questCrab=Dungeon.level.mobs.stream().filter(m->m.id()==107).findFirst().get();
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,questCrab.pos);
        if(questCrab.isAlive())cast(GuidingLight.INSTANCE,questCrab.pos);
        log("GREAT CRAB FREE THROW BEFORE LIGHT");
        Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfPurity.class).execute(Dungeon.hero,"DRINK");ready();log("DRINK PURITY AFTER OPENING QUEST BURST");
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfToxicGas.class,676);
        for(int c:new int[]{716,756,795,834,873,912})click(c);
        Dungeon.hero.search(true);ready();log("SEARCH ACTUAL SECRET DOOR 913");assertEquals(Terrain.DOOR,Dungeon.level.map[913]);
        for(int c:new int[]{913,953,993,1032,1072,1073,1074,1035})click(c);
        log("QUEST GAS FOLLOWED TOWARD CHILLING TRAP");
        Mob followingGnoll=Dungeon.level.mobs.stream().filter(m->m.id()==84).findFirst().get();
        cast(ShieldOfLight.INSTANCE,followingGnoll.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,questCrab.pos);
        assertFalse(questCrab.isAlive());log("GREAT CRAB FINISHED AT CORRIDOR CORNER");
        for(int n=0;n<2 && followingGnoll.isAlive();n++)click(followingGnoll.pos);
        assertFalse(followingGnoll.isAlive());log("QUEST ESCAPE FOLLOWING GNOLL DEFEATED");
        if(!Boolean.getBoolean("route.killSlimeBeforeTrap")){click(996);assertEquals(996,Dungeon.hero.pos);}
        Mob followingSlime=Dungeon.level.mobs.stream().filter(m->m.id()==83).findFirst().get();
        if(!Boolean.getBoolean("route.skipSlimeShield"))cast(ShieldOfLight.INSTANCE,followingSlime.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,followingSlime.pos);
        for(int n=0;n<4 && followingSlime.isAlive();n++)click(followingSlime.pos);
        assertFalse(followingSlime.isAlive());log("QUEST ESCAPE SLIME DEFEATED AT COLD TRAP");
        if(Boolean.getBoolean("route.killSlimeBeforeTrap"))assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfHealing.class));else assertNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfHealing.class));
        if(System.getProperty("route.checkpointQuestOut")!=null)writeCheckpoint(System.getProperty("route.checkpointQuestOut"));
        log("QUEST READY ACTUAL SURVIVOR");
        if(Boolean.getBoolean("route.stopAfterQuest"))return;
        if(Boolean.getBoolean("route.killSlimeBeforeTrap")){
            for(int c:new int[]{1073,1073,1072,1072,1072})click(c);
            click(1073);
            Mob lateCrab=Dungeon.level.mobs.stream().filter(m->m.id()==119).findFirst().get();
            cast(ShieldOfLight.INSTANCE,lateCrab.pos);
            for(int n=0;n<3 && lateCrab.isAlive();n++)click(lateCrab.pos);
            assertFalse(lateCrab.isAlive());log("LATE SPAWNED CRAB DEFEATED WITH SAVED CHARGE");
            assertEquals(5,Dungeon.hero.lvl);assertEquals(1,Dungeon.hero.talentPointsAvailable(1));
            Dungeon.hero.upgradeTalent(Talent.SATIATED_SPELLS);log("EARN SATIATED SPELLS AT LEVEL FIVE");
            for(int c:new int[]{1074,1035})click(c);
            Item meat=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.MysteryMeat.class);assertNotNull(meat);
            int meatQuantity=meat.quantity();
            meat.execute(Dungeon.hero,"DROP");ready();log("DROP OWNED RAW MEAT BEFORE TRIGGERING COLD");
            throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.melee.Cudgel.class,996);
            click(1074);log("LEAVE COLD WITH HEALING POTION RETAINED");
            for(int n=0;n<11;n++)waitOne();
            assertEquals(0,com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Blob.volumeAt(1035,com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Freezing.class));
            click(1035);click(1035);
            Item frozen=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.FrozenCarpaccio.class);assertNotNull(frozen);assertEquals(meatQuantity,frozen.quantity());
            assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfHealing.class));
            log("OWNED RAW MEAT SAFELY FROZEN AND RECOVERED");
            if(System.getProperty("route.checkpointFoodOut")!=null)writeCheckpoint(System.getProperty("route.checkpointFoodOut"));
        }
    }

    private void foodCheckpointSection() throws Exception {
        assertEquals(4,Dungeon.depth);assertEquals(1035,Dungeon.hero.pos);
        Item food=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.FrozenCarpaccio.class);assertNotNull(food);assertEquals(2,food.quantity());
        food.execute(Dungeon.hero,"EAT");ready();log("EAT ONE ACTUALLY FROZEN QUEST MEAT");
        cast(HolyWard.INSTANCE,null);assertEquals(3,Dungeon.hero.shielding());log("MEAL EARNED THREE SHIELD FROM SATIATED SPELLS");
        for(int c:new int[]{1036,1036,996,996,1035,1074,1073,1072,1032,993,953,913,912,873,834,795,756,717,676})click(c);
        log("RETURN TO GHOST AFTER COOKING AND MEAL");
        for(int c:new int[]{676,675,674,673,633,594,555,516,477})click(c);
        log("READY GHOST NORTH APPROACH WITH FOLLOWING SWARM");
        Mob swarm=Dungeon.level.mobs.stream().filter(m->m.id()==109).findFirst().get();cast(ShieldOfLight.INSTANCE,swarm.pos);
        click(478);log("GHOST FINAL PROTECTED APPROACH");click(479);
        com.shatteredpixel.shatteredpixeldungeon.items.armor.Armor reward=claimActualGhostArmor();assertEquals(1,reward.level());
        reward.execute(Dungeon.hero,"EQUIP");Dungeon.hero.busy();ready();log("EQUIP EARNED LEATHER ARMOR");
        upgradeOwnedGear(reward);assertEquals(2,reward.level());log("EARNED LEATHER ARMOR UPGRADED TO TWO");
        for(int c:new int[]{478,477,476,475,513,513})click(c);
        assertEquals(5,Dungeon.depth);assertEquals(708,Dungeon.hero.pos);log("GOO FLOOR RETURN WITH EARNED UPGRADED ARMOR");
        if(System.getProperty("route.checkpointArmored5Out")!=null)writeCheckpoint(System.getProperty("route.checkpointArmored5Out"));
    }
    private void upgradeOwnedGear(Item spear) throws Exception {
        Item scroll=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfUpgrade.class);
        assertNotNull(scroll);assertNotNull(spear);
        int oldLevel=spear.level();
        itemSelection=null;upgradeButton=null;
        scroll.execute(Dungeon.hero,"READ");assertNotNull(itemSelection);
        assertTrue(itemSelection.itemSelectable(spear));itemSelection.onSelect(spear);
        assertNotNull(upgradeButton);
        Method confirm=upgradeButton.getClass().getDeclaredMethod("onClick");confirm.setAccessible(true);confirm.invoke(upgradeButton);
        ready();log("READ OWNED UPGRADE ON OWNED GEAR");
        assertEquals(oldLevel+1,spear.level());assertNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfUpgrade.class));
    }

    private com.shatteredpixel.shatteredpixeldungeon.items.armor.Armor claimActualGhostArmor() throws Exception {
        com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.Ghost ghost=(com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.Ghost)Dungeon.level.mobs.stream().filter(m->m instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.Ghost).findFirst().get();
        assertTrue(Dungeon.level.adjacent(Dungeon.hero.pos,ghost.pos));
        assertTrue(com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.Ghost.Quest.processed());
        com.shatteredpixel.shatteredpixeldungeon.items.armor.Armor offered=com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.Ghost.Quest.armor;
        assertNotNull(offered);click(ghost.pos); //actual adjacent NPC interaction, with its normal quest gate
        //Rendering-only window substitute. The original reward handler performs the actual pickup, glyph assignment, NPC removal and quest completion.
        com.shatteredpixel.shatteredpixeldungeon.windows.WndSadGhost window=mock(com.shatteredpixel.shatteredpixeldungeon.windows.WndSadGhost.class);
        Field ghostField=window.getClass().getDeclaredField("ghost");ghostField.setAccessible(true);ghostField.set(window,ghost);
        com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.Ghost.Quest.revealOfferedLevels();
        Method choose=com.shatteredpixel.shatteredpixeldungeon.windows.WndSadGhost.class.getDeclaredMethod("selectReward",Item.class);choose.setAccessible(true);choose.invoke(window,offered);
        ready();log("CLAIM ACTUAL GHOST ARMOR THROUGH ORIGINAL REWARD HANDLER");
        assertTrue(com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.Ghost.Quest.completed());
        assertSame(offered,Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.armor.LeatherArmor.class));
        return offered;
    }

    private void buyActualShopHeap(int cell) throws Exception {
        Heap heap=Dungeon.level.heaps.get(cell);assertNotNull(heap);assertEquals(Heap.Type.FOR_SALE,heap.type);
        int price=com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.Shopkeeper.sellPrice(heap.peek());
        assertTrue("Cannot afford shop price "+price,Dungeon.gold>=price);
        tradeWindow=null;tradeHeap=null;executeTradeUi=true;
        try{click(cell);click(cell);}finally{executeTradeUi=false;}
        assertTrue(Dungeon.level.adjacent(Dungeon.hero.pos,cell) || Dungeon.hero.pos==cell);
        assertSame(heap,tradeHeap);assertNotNull(tradeWindow);
        Method buy=com.shatteredpixel.shatteredpixeldungeon.windows.WndTradeItem.class.getDeclaredMethod("buy",Heap.class);buy.setAccessible(true);
        Dungeon.hero.busy();buy.invoke(tradeWindow,heap);ready();log("BUY ACTUAL SHOP HEAP "+cell+" PRICE "+price);
    }

    private void eighthFloorAfterBless() throws Exception {
        for(int n=0;n<Integer.getInteger("route.guardPrepWait",0);n++)waitOne();
        for(int c:new int[]{808,776,744,712,680,648,647,646})click(c);
        cast(BlessSpell.INSTANCE,Dungeon.hero.pos);assertEquals(10,Dungeon.hero.shielding());
        click(614);log("FLOOR EIGHT GUARDED NORTHWEST DOOR WITH EARNED BLESS");
        Mob guard=Dungeon.level.mobs.stream().filter(m->m.id()==250).findFirst().get();
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,guard.pos);
        click(581);click(580);log("FLOOR EIGHT GUARD WITH DM LINE OF SIGHT BROKEN");
        click(guard.pos);click(guard.pos);click(guard.pos);
        log("FLOOR EIGHT GUARD MELEE WITHOUT A RESET");
        click(guard.pos);click(581);
        log("FLOOR EIGHT CLOSE DM TO MELEE AFTER GUARD STRIKE");
        click(guard.pos);log("FLOOR EIGHT GUARD FINISHER WITH DM ADJACENT");
        assertFalse(guard.isAlive());
        Mob dm=Dungeon.level.mobs.stream().filter(m->m.id()==265).findFirst().get();
        click(dm.pos);click(dm.pos);
        log("FLOOR EIGHT DM MELEE EXCHANGE");
        click(dm.pos);assertFalse(dm.isAlive());log("FLOOR EIGHT GUARD AND DM DEFEATED WITH RETAINED BLESS");
        for(int c:new int[]{549,549,549,517,518,519,520,521,522,490,458,426})click(c);
        assertEquals(426,Dungeon.hero.pos);
        Dungeon.hero.search(true);ready();log("REVEAL FLOOR EIGHT FOOD ROOM SECRET DOOR");
        assertEquals(Terrain.DOOR,Dungeon.level.map[427]);
        cast(BlessSpell.INSTANCE,Dungeon.hero.pos);
        click(427);assertEquals(427,Dungeon.hero.pos);log("FLOOR EIGHT FOOD ROOM DOOR AFTER SECOND EARNED BLESS");
        Mob foodDM=Dungeon.level.mobs.stream().filter(m->m.id()==251).findFirst().get();
        click(foodDM.pos);click(foodDM.pos);log("FLOOR EIGHT FOOD GUARD DM MELEE");
        assertFalse(foodDM.isAlive());
        click(396);assertEquals(396,Dungeon.hero.pos);
        assertNull(Dungeon.hero.buff(Vertigo.class));assertTrue(Dungeon.level.traps.get(428).active);
        for(int c:new int[]{364,365,365,366,366})click(c);
        assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.Pasty.class));
        assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfLevitation.class));
        log("FLOOR EIGHT PASTY AND LEVITATION ACTUALLY ACQUIRED WITHOUT TRIGGERING CONFUSION TRAP");
        if(System.getProperty("route.checkpoint8PastyOut")!=null)writeCheckpoint(System.getProperty("route.checkpoint8PastyOut"));
    }

    private void eighthFloorAfterRest() throws Exception {
        for(int c:new int[]{998,1031,1063})click(c);
        assertEquals(1063,Dungeon.hero.pos);
        for(int c:new int[]{1095,1127,1126,1125,1124,1123,1122,1090,1058,1026,994,962,930,898,899,900,901,902})click(c);
        assertEquals(902,Dungeon.hero.pos);
        log("FLOOR EIGHT WESTERN ROUTE PAST NECROMANCER RANGE");
        for(int c:new int[]{870,838})click(c);
        assertEquals(838,Dungeon.hero.pos);
        Mob skeleton=Dungeon.level.mobs.stream().filter(m->m.id()==254).findFirst().get();
        cast(GuidingLight.INSTANCE,skeleton.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,skeleton.pos);
        log("FLOOR EIGHT SPAWNED SKELETON RANGED OPENING");
        waitOne();waitOne();waitOne();
        cast(ShieldOfLight.INSTANCE,skeleton.pos);
        click(skeleton.pos);click(skeleton.pos);
        log("FLOOR EIGHT SPAWNED SKELETON SHIELDED MELEE");
        assertFalse(skeleton.isAlive());
        for(int c:new int[]{774,742,710,678,646})click(c);
        for(int n=0;n<9;n++)waitOne();
        click(647);click(648);
        Mob thief=Dungeon.level.mobs.stream().filter(m->m.id()==246).findFirst().get();
        cast(GuidingLight.INSTANCE,thief.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,thief.pos);
        log("FLOOR EIGHT THIEF AFTER EARNED SKELETON KILL");
        cast(GuidingLight.INSTANCE,thief.pos);assertFalse(thief.isAlive());
        assertEquals(7,Dungeon.hero.lvl);assertEquals(1,Dungeon.hero.talentPointsAvailable(2));
        Dungeon.hero.upgradeTalent(Talent.BLESS);log("EARN LEVEL SEVEN AND FIRST BLESS POINT");
        for(int c:new int[]{680,712,712,712,744,776,808,809,809})click(c);
        Item strength=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfStrength.class);assertNotNull(strength);
        strength.execute(Dungeon.hero,"DRINK");ready();assertEquals(14,Dungeon.hero.STR);log("DRINK FOURTH EARNED STRENGTH POTION");
        if(System.getProperty("route.checkpoint8BlessOut")!=null)writeCheckpoint(System.getProperty("route.checkpoint8BlessOut"));
    }

    private void activateOwnedHourglassFreeze() throws Exception {
        TimekeepersHourglass hourglass=Dungeon.hero.belongings.getItem(TimekeepersHourglass.class);assertNotNull(hourglass);assertTrue(hourglass.isEquipped(Dungeon.hero));
        hourglassWindow=null;hourglass.execute(Dungeon.hero,"ACTIVATE");assertNotNull("Original Hourglass choice window must open",hourglassWindow);
        Method select=hourglassWindow.getClass().getDeclaredMethod("onSelect",int.class);select.setAccessible(true);select.invoke(hourglassWindow,1);
        assertNotNull(Dungeon.hero.buff(TimekeepersHourglass.timeFreeze.class));log("ACTUAL HOURGLASS ORIGINAL FREEZE CHOICE");
    }
    private void activateOwnedHourglassStasis() throws Exception {
        TimekeepersHourglass hourglass=Dungeon.hero.belongings.getItem(TimekeepersHourglass.class);assertNotNull(hourglass);assertTrue(hourglass.isEquipped(Dungeon.hero));
        hourglassWindow=null;hourglass.execute(Dungeon.hero,"ACTIVATE");assertNotNull(hourglassWindow);
        Method select=hourglassWindow.getClass().getDeclaredMethod("onSelect",int.class);select.setAccessible(true);select.invoke(hourglassWindow,0);
        assertNotNull("Original stasis must attach",Dungeon.hero.buff(TimekeepersHourglass.timeStasis.class));
        Dungeon.hero.busy();ready();assertNull("Stasis must actually complete",Dungeon.hero.buff(TimekeepersHourglass.timeStasis.class));assertEquals(0,Dungeon.hero.paralysed);
        log("ACTUAL PAID STASIS COMPLETE BEFORE LEAVING GUARD ROOM");
    }
    private void eighthFloorHourglassGuard() throws Exception {
        assertEquals(214,Dungeon.hero.pos);
        for(int cell:new int[]{246,279,280,281,314})click(cell);
        log("PIT EXIT NORTHERN GUARD APPROACH");
        Mob guard=Dungeon.level.mobs.stream().filter(m->m instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Guard && Dungeon.level.heroFOV[m.pos]).findFirst().get();
        activateOwnedHourglassFreeze();
        if(Boolean.getBoolean("route.hourglassAttack")){
            click(guard.pos);
            assertNull("First attack must dispel actual time freeze",Dungeon.hero.buff(TimekeepersHourglass.timeFreeze.class));
            try{click(guard.pos);}catch(AssertionError expected){
                if(Dungeon.hero.isAlive())throw expected;
                assertTrue("Guard must still be alive in failed combat strategy",guard.isAlive());assertEquals(1,Dungeon.hero.HT);
                System.out.println("NEGATIVE_CONTROL_ATTACK_DISPELS_FREEZE_AND_GUARD_KILLS HP="+Dungeon.hero.HP+" guardHP="+guard.HP);
                return;
            }
            fail("Undefended Hourglass attack route unexpectedly survived; inspect negative control");
        }else{
            for(int cell:new int[]{347,379,411,442,474,507})click(cell);
            boolean early= Integer.getInteger("route.guardFreezeMoves",7)==6;
            if(early){Dungeon.hero.belongings.getItem(TimekeepersHourglass.class).execute(Dungeon.hero,"ACTIVATE");assertNull(Dungeon.hero.buff(TimekeepersHourglass.timeFreeze.class));log("END FREEZE AT DISTANCE FIVE AFTER SIX REAL MOVES");}
            click(540);
            if(!early && !Boolean.getBoolean("route.freezeAllTen")){
                Dungeon.hero.belongings.getItem(TimekeepersHourglass.class).execute(Dungeon.hero,"ACTIVATE");
                assertNull("Original deactivation must end freeze",Dungeon.hero.buff(TimekeepersHourglass.timeFreeze.class));log("END ACTUAL FREEZE AFTER SEVEN MOVES OUTSIDE CHAIN RANGE");
            }
            if(Boolean.getBoolean("route.breakGuardPursuitWithStasis"))activateOwnedHourglassStasis();
            for(int cell:new int[]{572,604,636})click(cell);
            assertEquals(636,Dungeon.hero.pos);assertTrue("Guard is bypassed, not secretly killed",guard.isAlive());
            log("NORTHERN GUARD BYPASSED USING ACTUAL FROZEN MOVEMENT");
        }
        if(System.getProperty("route.hourglassGuardOut")!=null)writeCheckpoint(System.getProperty("route.hourglassGuardOut"));
    }
    private void eighthFloorHourglassCentral() throws Exception {
        assertEquals(636,Dungeon.hero.pos);
        for(int cell:new int[]{668,700,732,763,762,793,825,857,889,921,953})click(cell);
        assertEquals(953,Dungeon.hero.pos);log("HOURGLASS BRANCH CENTRAL DOOR APPROACH WITH CONTINUOUS RESOURCES");
        if(System.getProperty("route.hourglassCentralOut")!=null)writeCheckpoint(System.getProperty("route.hourglassCentralOut"));
    }
    private void eighthFloorHourglassSkeleton() throws Exception {
        assertEquals(953,Dungeon.hero.pos);
        if(Boolean.getBoolean("route.hourglassRangedSkeleton")){
            click(984);cast(HolyWard.INSTANCE,null);
            Mob skeleton=Dungeon.level.mobs.stream().filter(m->m.id()==244).findFirst().get();
            cast(ShieldOfLight.INSTANCE,skeleton.pos);
            for(int n=0;n<3;n++)cast(GuidingLight.INSTANCE,skeleton.pos);
            assertTrue("Three 2..8 lights cannot alone kill a full 25-HP skeleton",skeleton.isAlive());
            assertNull("Owned missile must have earned its free cast cooldown",Dungeon.hero.buff(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.ShurikenInstantTracker.class));
            throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,skeleton.pos);
            assertFalse("Prepared skeleton must actually die",skeleton.isAlive());
            assertEquals("One skeleton cannot unlock Bless from 26 XP",6,Dungeon.hero.lvl);assertEquals(31,Dungeon.hero.exp);
            log("RECHARGED BRANCH REAL SKELETON CLEAR NO BLESS GRANTED");
            if(System.getProperty("route.hourglassSkeletonOut")!=null)writeCheckpoint(System.getProperty("route.hourglassSkeletonOut"));
            return;
        }
        Item rage=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfRage.class);assertNotNull(rage);
        if(Boolean.getBoolean("route.hourglassRageAtDoor")){
            click(984);log("CENTRAL ROOM BEFORE RETAINED RAGE AT ACTUAL DOOR");
            rage.execute(Dungeon.hero,"READ");ready();log("ACTUAL CENTRAL ROOM RAGE WITH VISIBLE SKELETON AND DM");
            if(System.getProperty("route.hourglassDoorOut")!=null)writeCheckpoint(System.getProperty("route.hourglassDoorOut"));
            return;
        }
        rage.execute(Dungeon.hero,"READ");ready();log("READ PRESERVED RAGE TO INTERRUPT PURSUING NORTHERN GUARD");
        click(984);click(984);log("CENTRAL ROOM ACTUAL DOOR ENTRY");
        Mob skeleton=Dungeon.level.mobs.stream().filter(m->m.id()==244).findFirst().get();
        cast(ShieldOfLight.INSTANCE,skeleton.pos);cast(GuidingLight.INSTANCE,skeleton.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,skeleton.pos);
        for(int n=0;n<3 && skeleton.isAlive();n++)click(skeleton.pos);
        assertFalse(skeleton.isAlive());log("HOURGLASS BRANCH CENTRAL SKELETON DEFEATED WITH ACTUAL XP ONLY");
        if(System.getProperty("route.hourglassBlessOut")!=null)writeCheckpoint(System.getProperty("route.hourglassBlessOut"));
    }
    private void eighthFloorHourglassDuel() throws Exception {
        assertEquals(984,Dungeon.hero.pos);
        click(1015);click(1044);assertEquals("Engine movement is interrupted at the actual cell, not the clicked target",1077,Dungeon.hero.pos);log("CENTRAL DUEL AFTER TWO INPUTS AND THREE ELAPSED TURNS");
        if(System.getProperty("route.hourglassDuelOut")!=null)writeCheckpoint(System.getProperty("route.hourglassDuelOut"));
    }
    private void eighthFloorHourglassDM() throws Exception {
        assertEquals(984,Dungeon.hero.pos);assertEquals(31,Dungeon.hero.exp);assertEquals(6,Dungeon.hero.lvl);
        Mob dm=Dungeon.level.mobs.stream().filter(m->m.id()==245).findFirst().get();assertEquals(1138,dm.pos);
        activateOwnedHourglassFreeze();
        for(int cell:new int[]{1015,1046,1077,1108})click(cell);
        assertEquals(1108,Dungeon.hero.pos);assertEquals("DM must remain at actual frozen cell",1138,dm.pos);
        assertNull("Exactly four moves consume the two owned Hourglass charges",Dungeon.hero.buff(TimekeepersHourglass.timeFreeze.class));
        click(1139);assertEquals(1139,Dungeon.hero.pos);assertTrue(Dungeon.level.adjacent(Dungeon.hero.pos,dm.pos));log("ACTUAL ADJACENT DM APPROACH AFTER FOUR FROZEN MOVES");
        for(int n=0;n<4 && dm.isAlive();n++){
            assertTrue(Dungeon.level.adjacent(Dungeon.hero.pos,dm.pos));click(dm.pos);
            if(n==0 && Boolean.getBoolean("route.hourglassRageAfterFirstHit")){
                Item rage=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfRage.class);assertNotNull(rage);
                rage.execute(Dungeon.hero,"READ");ready();log("RETAINED RAGE AFTER FIRST DM HIT WITH GUARD AND NECROMANCER VISIBLE");
                if(System.getProperty("route.hourglassDMRageOut")!=null)writeCheckpoint(System.getProperty("route.hourglassDMRageOut"));
                return;
            }
        }
        assertFalse("Real adjacent DM encounter must be completed",dm.isAlive());assertEquals(7,Dungeon.hero.lvl);assertEquals(1,Dungeon.hero.talentPointsAvailable(2));
        Dungeon.hero.upgradeTalent(Talent.BLESS);log("RECHARGED HOURGLASS BRANCH EARNS BLESS AFTER BOTH REAL ENCOUNTERS");
        if(System.getProperty("route.hourglassDMOut")!=null)writeCheckpoint(System.getProperty("route.hourglassDMOut"));
    }
    private void eighthFloorHourglassFinishDM() throws Exception {
        assertEquals(1139,Dungeon.hero.pos);
        Mob dm=Dungeon.level.mobs.stream().filter(m->m.id()==245).findFirst().get();
        for(int n=0;n<4 && dm.isAlive();n++)click(dm.pos);
        assertFalse("DM must really be dead, including any paid Rage interaction",dm.isAlive());
        assertEquals(7,Dungeon.hero.lvl);assertEquals(1,Dungeon.hero.talentPointsAvailable(2));Dungeon.hero.upgradeTalent(Talent.BLESS);
        log("CONTINUOUS PIT RECHARGE SKELETON DM AND RAGE ROUTE ACTUALLY EARNS BLESS");
        if(System.getProperty("route.hourglassBlessEarnedOut")!=null)writeCheckpoint(System.getProperty("route.hourglassBlessEarnedOut"));
    }
    private void eighthFloorHourglassBlessEscape() throws Exception {
        assertEquals(1077,Dungeon.hero.pos);assertEquals(1,Dungeon.hero.pointsInTalent(Talent.BLESS));
        for(int cell:new int[]{1076,1043,1042,1073,1072,1071,1102,1133,1164}){click(cell);assertEquals("Actual escape movement must reach the requested adjacent cell",cell,Dungeon.hero.pos);}
        log("ACTUAL POST DUEL ESCAPE WITH ALL REMAINING ENEMIES");
        if(System.getProperty("route.hourglassEscapeOut")!=null)writeCheckpoint(System.getProperty("route.hourglassEscapeOut"));
    }
    private void eighthFloorHourglassFirstBless() throws Exception {
        assertEquals(1164,Dungeon.hero.pos);assertEquals(1,Dungeon.hero.pointsInTalent(Talent.BLESS));
        assertEquals("No whole charge may be granted at this checkpoint",0,charge(Dungeon.hero.belongings.getItem(HolyTome.class)));
        click(1131);assertEquals(1131,Dungeon.hero.pos);
        assertTrue("The move must actually earn the first whole charge",charge(Dungeon.hero.belongings.getItem(HolyTome.class))>=1);
        cast(BlessSpell.INSTANCE,Dungeon.hero.pos);log("FIRST REAL BLESS CAST AFTER PAID RECHARGE AND CHASING ENEMIES");
        if(System.getProperty("route.hourglassFirstBlessOut")!=null)writeCheckpoint(System.getProperty("route.hourglassFirstBlessOut"));
    }
    private void eighthFloorHourglassThiefApproach() throws Exception {
        assertEquals(1131,Dungeon.hero.pos);
        click(1098);assertEquals(1098,Dungeon.hero.pos);
        Mob thief=Dungeon.level.mobs.stream().filter(m->m.id()==242).findFirst().get();assertTrue(Dungeon.level.adjacent(Dungeon.hero.pos,thief.pos));
        click(thief.pos);log("ACTUAL THIEF EXCHANGE WHILE NECRO SKELETON CONTINUES CHASING");
        if(System.getProperty("route.hourglassThiefOut")!=null)writeCheckpoint(System.getProperty("route.hourglassThiefOut"));
    }
    private void eighthFloorHourglassWestFight() throws Exception {
        assertEquals(1098,Dungeon.hero.pos);
        Mob thief=Dungeon.level.mobs.stream().filter(m->m.id()==242).findFirst().orElse(null);
        for(int n=0;n<Integer.getInteger("route.westThiefAttempts",2) && thief!=null && thief.isAlive() && Dungeon.level.adjacent(Dungeon.hero.pos,thief.pos);n++)click(thief.pos);
        log("ACTUAL THIEF FOLLOW UP ATTEMPTS NO STOLEN ITEMS RESTORED");
        if(Boolean.getBoolean("route.westFocusFront")){
            Mob front=Dungeon.level.mobs.stream().filter(m->m.id()==279).findFirst().get();
            Mob rear=Dungeon.level.mobs.stream().filter(m->m.id()==281).findFirst().get();
            for(int n=0;n<4 && !Dungeon.level.adjacent(Dungeon.hero.pos,front.pos);n++){
                assertTrue(Dungeon.level.adjacent(Dungeon.hero.pos,rear.pos));click(rear.pos);
            }
            assertTrue("Northern corridor blocker must actually arrive",Dungeon.level.adjacent(Dungeon.hero.pos,front.pos));
            for(int n=0;n<8 && front.isAlive();n++){assertTrue(Dungeon.level.adjacent(Dungeon.hero.pos,front.pos));click(front.pos);}
            assertFalse("Ordinary northern skeleton must really die",front.isAlive());log("ACTUAL NORTHERN SKELETON CLEAR HEALED MINION NOT REMOVED");
            if(System.getProperty("route.hourglassFrontClearOut")!=null)writeCheckpoint(System.getProperty("route.hourglassFrontClearOut"));
            return;
        }
        Mob skeleton=Dungeon.level.mobs.stream().filter(m->m.id()==281).findFirst().get();
        for(int n=0;n<5 && skeleton.isAlive();n++){assertTrue(Dungeon.level.adjacent(Dungeon.hero.pos,skeleton.pos));click(skeleton.pos);}
        assertFalse("Real chasing necro skeleton must be dead",skeleton.isAlive());log("ACTUAL NECRO SKELETON CLEAR WITH ITS REAL EXPLOSION");
        if(System.getProperty("route.hourglassWestClearOut")!=null)writeCheckpoint(System.getProperty("route.hourglassWestClearOut"));
    }
    private void eighthFloorHourglassCasterFocus() throws Exception {
        assertEquals(1098,Dungeon.hero.pos);
        for(int cell:new int[]{1130,1163}){click(cell);assertEquals(cell,Dungeon.hero.pos);}
        Mob necro=Dungeon.level.mobs.stream().filter(m->m.id()==235).findFirst().get();assertEquals(1164,necro.pos);
        for(int n=0;n<6 && necro.isAlive();n++){assertTrue(Dungeon.level.adjacent(Dungeon.hero.pos,necro.pos));click(necro.pos);}
        assertFalse("Original necromancer must actually die",necro.isAlive());
        assertFalse("Its minion must die through original owner-death code",Dungeon.level.mobs.stream().anyMatch(m->m.id()==281 && m.isAlive()));
        log("ACTUAL NECROMANCER AND OWNED MINION DEFEATED WITHOUT RESET");
        if(System.getProperty("route.hourglassCasterClearOut")!=null)writeCheckpoint(System.getProperty("route.hourglassCasterClearOut"));
    }
    private void ninthFloorSection() throws Exception {
        assertEquals(9,Dungeon.depth);
        if(Dungeon.hero.pos==1141){
            for(int n=0;n<Integer.getInteger("route.nineRecharge",130);n++)waitOne();
            log("ACTUAL FLOOR NINE PAID RECHARGE AFTER ISOLATED DM");
            if(System.getProperty("route.floorNineRestOut")!=null)writeCheckpoint(System.getProperty("route.floorNineRestOut"));return;
        }
        assertEquals(1095,Dungeon.hero.pos);
        Mob dm=Dungeon.level.mobs.stream().filter(m->m.id()==273).findFirst().get();assertEquals(1188,dm.pos);
        activateOwnedHourglassFreeze();click(1141);assertEquals(1141,Dungeon.hero.pos);
        assertNull("One slowed movement must spend both frozen turns",Dungeon.hero.buff(TimekeepersHourglass.timeFreeze.class));
        assertTrue(Dungeon.level.adjacent(Dungeon.hero.pos,dm.pos));
        Item healing=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfHealing.class);assertNotNull(healing);healing.execute(Dungeon.hero,"DRINK");ready();assertNull(Dungeon.hero.buff(Cripple.class));log("REAL FLOOR NINE CURE AFTER FROZEN ADJACENT APPROACH");
        for(int n=0;n<4 && dm.isAlive();n++){assertTrue(Dungeon.level.adjacent(Dungeon.hero.pos,dm.pos));click(dm.pos);}
        assertFalse("Actual floor-nine landing DM must die",dm.isAlive());assertEquals(6,Dungeon.hero.lvl);assertEquals(32,Dungeon.hero.exp);
        log("ACTUAL FLOOR NINE ISOLATED DM DEFEATED WITH CONTINUOUS RESOURCES");
        if(System.getProperty("route.floorNineDMOut")!=null)writeCheckpoint(System.getProperty("route.floorNineDMOut"));
    }
    private void eighthFloorFallToNine() throws Exception {
        assertEquals(953,Dungeon.hero.pos);cast(HolyWard.INSTANCE,null);
        jumpIntoKnownChasm(922);assertEquals(9,Dungeon.depth);
        assertNull(Dungeon.hero.buff(com.shatteredpixel.shatteredpixeldungeon.levels.features.Chasm.Falling.class));
        waitOne();assertNull(Dungeon.hero.buff(Bleeding.class));assertEquals(1,Dungeon.hero.HP);assertEquals(1,Dungeon.hero.HT);
        log("ACTUAL FLOOR NINE FALL LANDING BEFORE CURE");
        if(Boolean.getBoolean("route.stopBeforeCure")){
            System.out.println("FLOOR_LAYOUT "+new JSONObject().put("depth",9).put("width",Dungeon.level.width()).put("height",Dungeon.level.height()).put("terrain",new JSONArray(Dungeon.level.map)).put("entrance",Dungeon.level.entrance()).put("exit",Dungeon.level.exit()));
            if(System.getProperty("route.floorNineFallOut")!=null)writeCheckpoint(System.getProperty("route.floorNineFallOut"));return;
        }
        Item healing=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfHealing.class);assertNotNull(healing);
        healing.execute(Dungeon.hero,"DRINK");ready();assertNull(Dungeon.hero.buff(Cripple.class));log("CURE FALL CRIPPLE WITH OWNED HEALING POTION HP REMAINS ONE");
        System.out.println("FLOOR_LAYOUT "+new JSONObject().put("depth",9).put("width",Dungeon.level.width()).put("height",Dungeon.level.height()).put("terrain",new JSONArray(Dungeon.level.map)).put("entrance",Dungeon.level.entrance()).put("exit",Dungeon.level.exit()));
        if(System.getProperty("route.floorNineFallOut")!=null)writeCheckpoint(System.getProperty("route.floorNineFallOut"));
    }
    private void eighthFloorSection() throws Exception {
        if(Dungeon.hero.pos==1098){if(Boolean.getBoolean("route.hourglassCasterFocus"))eighthFloorHourglassCasterFocus();else eighthFloorHourglassWestFight();return;}
        if(Dungeon.hero.pos==1131){eighthFloorHourglassThiefApproach();return;}
        if(Dungeon.hero.pos==1164){eighthFloorHourglassFirstBless();return;}
        if(Dungeon.hero.pos==1077){eighthFloorHourglassBlessEscape();return;}
        if(Dungeon.hero.pos==1139){eighthFloorHourglassFinishDM();return;}
        if(Dungeon.hero.pos==984){if(Boolean.getBoolean("route.hourglassMeleeDM"))eighthFloorHourglassDM();else eighthFloorHourglassDuel();return;}
        if(Dungeon.hero.pos==953){if(Boolean.getBoolean("route.fallToNine"))eighthFloorFallToNine();else eighthFloorHourglassSkeleton();return;}
        if(Dungeon.hero.pos==636){eighthFloorHourglassCentral();return;}
        if(Dungeon.hero.pos==214){eighthFloorHourglassGuard();return;}
        if(Dungeon.hero.pos==809){eighthFloorAfterBless();return;}
        assertEquals(997,Dungeon.hero.pos);
        if(Boolean.getBoolean("route.eightContinue")){eighthFloorAfterRest();return;}
        for(int n=0;n<Integer.getInteger("route.eightWait",225);n++)waitOne();
        log("FLOOR EIGHT PAID ENTRANCE RECHARGE");
        if(System.getProperty("route.checkpoint8RestOut")!=null)writeCheckpoint(System.getProperty("route.checkpoint8RestOut"));
    }

    private void seventhFloorAfterIntercept() throws Exception {
        for(int c:new int[]{506,473,440,407,408,409,410,411,412,413,414,447,448,449,450,482,515,548,581,614,647,680,713,746,779,812})click(c);
        log("FLOOR SEVEN SOUTHBOUND APPROACH WITH RETAINED RAGE");
        for(int c:new int[]{845,878})click(c);
        log("FLOOR SEVEN EXIT GROUP BEFORE RAGE");
        if(Boolean.getBoolean("route.guardPullAudit")){
            try{click(911);}catch(AssertionError expected){
                if(Dungeon.hero.isAlive())throw expected;
                assertTrue(chainAnimationsCompleted>0);assertTrue(pushAnimationsCompleted>0);
                assertNotEquals(911,Dungeon.hero.pos);assertEquals(1,Dungeon.hero.HT);
                System.out.println("NEGATIVE_CONTROL_REAL_CHAIN_PULL_AND_DEATH pos="+Dungeon.hero.pos+" HP="+Dungeon.hero.HP);
                return;
            }
            fail("Unprotected chain route unexpectedly survived; inspect before updating this negative control");
        }
        Mob trailingSkeleton=Dungeon.level.mobs.stream().filter(m->m.id()==230).findFirst().get();
        cast(ShieldOfLight.INSTANCE,trailingSkeleton.pos);
        Item rage=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfRage.class);assertNotNull(rage);
        rage.execute(Dungeon.hero,"READ");ready();log("READ RETAINED RAGE BEFORE GUARD CHAIN");
        for(int c:new int[]{911,944,977,977})click(c);
        assertEquals(8,Dungeon.depth);log("EARNED FLOOR EIGHT ENTRY");
        System.out.println("FLOOR_LAYOUT "+new JSONObject().put("depth",Dungeon.depth).put("width",Dungeon.level.width()).put("height",Dungeon.level.height()).put("terrain",new JSONArray(Dungeon.level.map)).put("entrance",Dungeon.level.entrance()).put("exit",Dungeon.level.exit()));
        if(System.getProperty("route.checkpoint8Out")!=null)writeCheckpoint(System.getProperty("route.checkpoint8Out"));
    }

    private void seventhFloorFood() throws Exception {
        for(int n=0;n<40;n++)waitOne();
        Item food=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.Food.class);assertNotNull(food);
        food.execute(Dungeon.hero,"EAT");ready();log("EAT ACQUIRED FLOOR SEVEN RATION AFTER PAID FORTY TURNS");
        for(int n=0;n<(Boolean.getBoolean("route.interceptThief")?31:65);n++)waitOne();
        log("FLOOR SEVEN SECOND FOOD FUNDED RECHARGE INTERRUPTED BY THIEF");
        Mob thief=Dungeon.level.mobs.stream().filter(m->m.id()==222).findFirst().get();
        if(Boolean.getBoolean("route.interceptThief")){
            cast(GuidingLight.INSTANCE,thief.pos);
            throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,thief.pos);
            log("INTERCEPT THIRD THIEF APPROACH BEFORE RAGE THEFT");
            cast(GuidingLight.INSTANCE,thief.pos);
            log("INTERCEPT THIRD THIEF SECOND LIGHT");
            waitOne();waitOne();click(thief.pos);assertFalse(thief.isAlive());
            for(int c:new int[]{538,538,538})click(c);
            log("INTERCEPT THIEF DEFEATED RAGE RETAINED AND MISSILE RECOVERED");
            assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfRage.class));
            assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class));
            if(System.getProperty("route.checkpoint7InterceptOut")!=null)writeCheckpoint(System.getProperty("route.checkpoint7InterceptOut"));
            return;
        }
        cast(ShieldOfLight.INSTANCE,thief.pos);
        cast(GuidingLight.INSTANCE,thief.pos);
        click(thief.pos);log("FLOOR SEVEN RESPAWNED THIEF EXCHANGE");
        if(System.getProperty("route.checkpoint7FoodRestOut")!=null)writeCheckpoint(System.getProperty("route.checkpoint7FoodRestOut"));
    }

    private void seventhFloorAfterRest() throws Exception {
        for(int c:new int[]{819,786,753,720,687,686,685,652,619,586,553,520,487,455,422,421,420,419})click(c);
        Dungeon.hero.search(true);ready();log("SEARCH FLOOR SEVEN EASTERN ARENA SECRET DOOR");
        for(int c:new int[]{418,417,416,415,414})click(c);
        cast(HolyWard.INSTANCE,null);
        Mob skeleton=Dungeon.level.mobs.stream().filter(m->m.id()==202).findFirst().get();
        cast(GuidingLight.INSTANCE,skeleton.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,skeleton.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,skeleton.pos);
        log("FLOOR SEVEN CENTRAL APPROACH");
        cast(GuidingLight.INSTANCE,skeleton.pos);
        cast(GuidingLight.INSTANCE,skeleton.pos);assertFalse(skeleton.isAlive());
        log("FLOOR SEVEN FIRST SKELETON DEFEATED");
        for(int c:new int[]{447,448,448,414})click(c);
        assertEquals(1,Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class).quantity());
        Mob northSkeleton=Dungeon.level.mobs.stream().filter(m->m.id()==201).findFirst().get();
        cast(ShieldOfLight.INSTANCE,northSkeleton.pos);
        waitOne();waitOne();
        cast(GuidingLight.INSTANCE,northSkeleton.pos);
        click(northSkeleton.pos);
        log("FLOOR SEVEN NORTH SKELETON EXCHANGE");
        click(northSkeleton.pos);assertFalse(northSkeleton.isAlive());
        log("FLOOR SEVEN SECOND SKELETON DEFEATED");
        for(int c:new int[]{413,412,411,410,409,408,407,440})click(c);
        log("FLOOR SEVEN FOOD GUARD APPROACH");
        Mob foodSkeleton=Dungeon.level.mobs.stream().filter(m->m.id()==199).findFirst().get();
        click(foodSkeleton.pos);log("FLOOR SEVEN FOOD GUARD MELEE");
        click(foodSkeleton.pos);click(foodSkeleton.pos);
        log("FLOOR SEVEN FOOD GUARD CONTINUED MELEE");
        assertFalse(foodSkeleton.isAlive());
        for(int c:new int[]{407,440,473,506,506})click(c);
        Item acquiredFood=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.Food.class);assertNotNull(acquiredFood);
        log("FLOOR SEVEN FOOD ACTUALLY ACQUIRED");
        if(System.getProperty("route.checkpoint7FoodOut")!=null)writeCheckpoint(System.getProperty("route.checkpoint7FoodOut"));
    }

    private void jumpIntoKnownChasm(int cell) throws Exception {
        assertTrue("Jump destination must actually be a pit",Dungeon.level.pit[cell]);
        assertTrue("Must stand adjacent before asking to jump",Dungeon.level.adjacent(Dungeon.hero.pos,cell));
        executeChasmUi=true;chasmWindow=null;
        try{click(cell);}finally{executeChasmUi=false;}
        assertNotNull("Original chasm confirmation UI must open",chasmWindow);
        //A real-time UI wait, not game time or a gameplay-state change. Invoke the original yes-button callback.
        Field elapsed=chasmWindow.getClass().getDeclaredField("elapsed");elapsed.setAccessible(true);elapsed.setFloat(chasmWindow,0.3f);
        Method select=chasmWindow.getClass().getDeclaredMethod("onSelect",int.class);select.setAccessible(true);select.invoke(chasmWindow,0);
        Dungeon.hero.busy();ready();log("ORIGINAL CONFIRMED CHASM TRANSITION COMPLETE");
    }
    private void hourglassAccessSection() throws Exception {
        assertEquals(7,Dungeon.depth);assertEquals(538,Dungeon.hero.pos);
        for(int cell:new int[]{504,472,440,408,376,377,378,379,380,348,314,280,279,278,277,276})click(cell);
        assertEquals(276,Dungeon.hero.pos);log("WEAK FLOOR ROOM REACHED FROM RETAINED THIEF CHECKPOINT");
        int preFallShield=Dungeon.hero.shielding();
        jumpIntoKnownChasm(275);assertEquals("Fall must not consume shielding",preFallShield,Dungeon.hero.shielding());assertEquals(8,Dungeon.depth);assertEquals(1,Dungeon.hero.HP);assertEquals(1,Dungeon.hero.HT);
        assertNull("Actual Falling actor must finish before claiming survival",Dungeon.hero.buff(com.shatteredpixel.shatteredpixeldungeon.levels.features.Chasm.Falling.class));
        waitOne();
        assertNull("Zero bleeding must detach before claiming survival",Dungeon.hero.buff(Bleeding.class));
        log("ACTUAL PIT ROOM LANDING BEFORE ITEM ACCESS");
        for(int cell:new int[]{207,176,177,177,177,177,177})click(cell);
        assertNotNull("Hourglass must be acquired from actual remains",Dungeon.hero.belongings.getItem(TimekeepersHourglass.class));
        assertEquals("Actual gold from this heap",164,Dungeon.gold);
        log("HOURGLASS AND PIT CRYSTAL KEY ACTUALLY ACQUIRED");
        TimekeepersHourglass hourglass=Dungeon.hero.belongings.getItem(TimekeepersHourglass.class);
        hourglass.execute(Dungeon.hero,"EQUIP");Dungeon.hero.busy();ready();assertTrue(hourglass.isEquipped(Dungeon.hero));log("ACTUAL HOURGLASS EQUIPPED IN FREE MISC SLOT");
        for(int n=0;n<Integer.getInteger("route.pitRecharge",0);n++)waitOne();
        if(Integer.getInteger("route.pitRecharge",0)>0)log("PAID NATIVE PIT ROOM RECHARGE BEFORE CRYSTAL EXIT");
        for(int cell:new int[]{178,179,180,212,213,213,214})click(cell);
        assertEquals("Must actually escape the pit room through the owned crystal key",214,Dungeon.hero.pos);
        assertEquals(0,com.shatteredpixel.shatteredpixeldungeon.journal.Notes.keyCount(new com.shatteredpixel.shatteredpixeldungeon.items.keys.CrystalKey(8)));
        Field hourglassCharge=Artifact.class.getDeclaredField("charge");hourglassCharge.setAccessible(true);
        Field hourglassPartial=Artifact.class.getDeclaredField("partialCharge");hourglassPartial.setAccessible(true);
        assertEquals("No Hourglass charge granted or spent",5,hourglassCharge.getInt(hourglass));
        System.out.println("HOURGLASS_DETAIL charge="+hourglassCharge.getInt(hourglass)+" partial="+hourglassPartial.getFloat(hourglass)+" cursed="+hourglass.cursed+" equipped="+hourglass.isEquipped(Dungeon.hero));
        log("ACTUAL PIT ROOM EXIT UNLOCKED AND ESCAPED WITH HOURGLASS");
        if(System.getProperty("route.hourglassOut")!=null)writeCheckpoint(System.getProperty("route.hourglassOut"));
    }
    private void seventhFloorSection() throws Exception {
        if(Boolean.getBoolean("route.hourglassAccess")){hourglassAccessSection();return;}
        if(Dungeon.hero.pos==538){seventhFloorAfterIntercept();return;}
        if(Dungeon.hero.pos==506){seventhFloorFood();return;}
        assertEquals(818,Dungeon.hero.pos);
        if(Boolean.getBoolean("route.sevenContinue")){seventhFloorAfterRest();return;}
        Item food=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.Food.class);assertNotNull(food);
        assertEquals(com.shatteredpixel.shatteredpixeldungeon.items.food.Food.class,food.getClass());
        food.execute(Dungeon.hero,"EAT");ready();log("EAT RECOVERED FULL RATION AT FLOOR SEVEN ENTRANCE");
        for(int n=0;n<Integer.getInteger("route.sevenWait",200);n++)waitOne();
        log("FLOOR SEVEN PAID ENTRANCE RECHARGE");
        if(System.getProperty("route.checkpoint7RestOut")!=null)writeCheckpoint(System.getProperty("route.checkpoint7RestOut"));
    }

    private void sixthFloorSection() throws Exception {
        if(Dungeon.hero.pos==334){sixthFloorNorth();return;}
        if(Dungeon.hero.pos==850){sixthFloorAfterUpgrade();return;}
        if(Dungeon.hero.pos==904){sixthFloorAfterStrength();return;}
        if(Dungeon.hero.pos==620){sixthFloorAfterFood();return;}
        for(int c:new int[]{644,613,582,583,584,585,586,587,588,589})click(c);
        buyActualShopHeap(620);
        Item ration=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.SmallRation.class);assertNotNull(ration);
        ration.execute(Dungeon.hero,"EAT");ready();log("EAT PURCHASED FLOOR SIX RATION");
        if(System.getProperty("route.checkpoint6FoodOut")!=null)writeCheckpoint(System.getProperty("route.checkpoint6FoodOut"));
    }

    private void sixthFloorNorth() throws Exception {
        Mob skeleton=Dungeon.level.mobs.stream().filter(m->m.id()==164).findFirst().get();
        click(333);log("FLOOR SIX NORTHWEST SIGHTLINE");
        cast(GuidingLight.INSTANCE,skeleton.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,skeleton.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,skeleton.pos);
        log("FLOOR SIX SPAWNED SKELETON EXCHANGE");
        assertFalse(skeleton.isAlive());
        for(int c:new int[]{365,366,367,367,366,334,333,301,269,237,205,173})click(c);
        log("FLOOR SIX UPPER ROOM APPROACH");
        cast(HolyWard.INSTANCE,null);
        for(int c:new int[]{141,109,77,78,79})click(c);
        Mob thief=Dungeon.level.mobs.stream().filter(m->m.id()==151).findFirst().get();
        cast(GuidingLight.INSTANCE,thief.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,thief.pos);
        log("FLOOR SIX THIEF OPENING");
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,thief.pos);
        assertFalse(thief.isAlive());assertEquals(6,Dungeon.hero.lvl);
        Dungeon.hero.upgradeTalent(Talent.SEARING_LIGHT);log("EARN LEVEL SIX AND SECOND SEARING LIGHT POINT");
        for(int c:new int[]{80,81,82,82,82,82,114,114})click(c);
        assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.Food.class));
        assertEquals(2,Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfHealing.class).quantity());
        log("RECOVER STOLEN FOOD MISSILES AND UPPER HEALING POTION");
        for(int c:new int[]{81,81,81})click(c);
        log("FLOOR SIX RESPAWNED SWARM FIRST EXCHANGE");
        for(int c:new int[]{82,81,81})click(c);
        log("FLOOR SIX RESPAWNED SWARM SECOND EXCHANGE");
        for(int c:new int[]{82,81,80,80})click(c);
        log("FLOOR SIX RESPAWNED SWARM CLEANUP");
        click(111);log("FLOOR SIX LAST SWARM CHILD");
        assertFalse(Dungeon.level.mobs.stream().anyMatch(m->m instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Swarm));
        for(int c:new int[]{81,82,83,84,85,117,149,181,213,245,244,243,242,274,275,276,277,278,279,280,281,313})click(c);
        log("FLOOR SIX FINAL EXIT APPROACH");
        Mob exitSkeleton=Dungeon.level.mobs.stream().filter(m->m.id()==186).findFirst().get();
        cast(ShieldOfLight.INSTANCE,exitSkeleton.pos);
        click(312);click(312);assertEquals(7,Dungeon.depth);log("EARNED FLOOR SEVEN ENTRY");
        System.out.println("FLOOR_LAYOUT "+new JSONObject().put("depth",Dungeon.depth).put("width",Dungeon.level.width()).put("height",Dungeon.level.height()).put("terrain",new JSONArray(Dungeon.level.map)).put("entrance",Dungeon.level.entrance()).put("exit",Dungeon.level.exit()));
        if(System.getProperty("route.checkpoint7Out")!=null)writeCheckpoint(System.getProperty("route.checkpoint7Out"));
    }

    private void sixthFloorAfterUpgrade() throws Exception {
        for(int c:new int[]{818,819,820,788,756,724,692,660,628,596,564,565,566,567,568,569})click(c);
        Dungeon.hero.search(true);ready();log("SEARCH FLOOR SIX EASTERN SECRET DOOR");
        for(int c:new int[]{537,505,473,474,475})click(c);
        Dungeon.hero.search(true);ready();log("SEARCH FLOOR SIX NORTHERN SECRET DOOR");
        for(int c:new int[]{443,411,379,347,315,314,313})click(c);
        assertEquals(313,Dungeon.hero.pos);
        log("FLOOR SIX NORTHERN EXIT ROOM APPROACH");
        cast(HolyWard.INSTANCE,null);
        for(int c:new int[]{345,344,343,342,341})click(c);
        log("FLOOR SIX SWARM MELEE APPROACH");
        for(int c:new int[]{372,371,371})click(c);
        log("FLOOR SIX SWARM FIRST MELEE EXCHANGE");
        for(int c:new int[]{371,371,371})click(c);
        log("FLOOR SIX SWARM SECOND MELEE EXCHANGE");
        for(int c:new int[]{339,339})click(c);
        log("FLOOR SIX SWARM CHILD EXCHANGE");
        for(int c:new int[]{339,340,340})click(c);
        log("FLOOR SIX SWARM CLEANUP");
        assertFalse(Dungeon.level.mobs.stream().anyMatch(m->m.id()==150||m.id()==173||m.id()==177));
        for(int c:new int[]{371,370,369,368,367,366,334,334})click(c);
        Item food=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.Food.class);assertNotNull(food);
        assertTrue(food instanceof com.shatteredpixel.shatteredpixeldungeon.items.food.SmallRation);
        food.execute(Dungeon.hero,"EAT");ready();log("EAT CARRIED SMALL RATION AFTER ACQUIRING NORTHERN FOOD");
        if(System.getProperty("route.checkpoint6NorthOut")!=null)writeCheckpoint(System.getProperty("route.checkpoint6NorthOut"));
    }

    private void sixthFloorAfterStrength() throws Exception {
        for(int c:new int[]{873,842,810,779,780,812,813,814})click(c);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.melee.Cudgel.class,817);
        log("OPEN SKELETON CORRIDOR DOOR FROM RANGE THREE");
        Mob skeleton=Dungeon.level.mobs.stream().filter(m->m.id()==149).findFirst().get();
        cast(GuidingLight.INSTANCE,skeleton.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,skeleton.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,skeleton.pos);
        log("SECOND SKELETON RANGED EXCHANGE");
        cast(GuidingLight.INSTANCE,skeleton.pos);assertFalse(skeleton.isAlive());
        for(int c:new int[]{815,816,816,817,817,818,850,850})click(c);
        assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfUpgrade.class));
        upgradeOwnedGear(Dungeon.hero.belongings.armor());
        assertEquals(3,Dungeon.hero.belongings.armor().level());
        if(System.getProperty("route.checkpoint6UpgradeOut")!=null)writeCheckpoint(System.getProperty("route.checkpoint6UpgradeOut"));
    }

    private void sixthFloorAfterFood() throws Exception {
        for(int c:new int[]{587,555,523,491})click(c);
        buyActualShopHeap(459);
        assertNotNull(Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.SmallRation.class));
        for(int c:new int[]{491,523,555,587,586,585,584,615,646,678,710,711,712,713,745,777,778})click(c);
        Dungeon.hero.search(true);ready();log("REVEAL FLOOR SIX CORRIDOR OOZE TRAP");
        click(777);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.melee.Cudgel.class,779);
        for(int c:new int[]{778,779,779,780})click(c);
        log("FLOOR SIX SOUTHERN APPROACH WITH SECOND PAID RATION");
        cast(HolyWard.INSTANCE,null);
        for(int c:new int[]{779,810,842})click(c);
        log("FLOOR SIX STRENGTH ROOM APPROACH");
        Mob skeleton=Dungeon.level.mobs.stream().filter(m->m.id()==148).findFirst().get();
        cast(GuidingLight.INSTANCE,skeleton.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,skeleton.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,skeleton.pos);
        log("FLOOR SIX FIRST SKELETON RANGED EXCHANGE");
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,skeleton.pos);
        assertFalse("Skeleton must die before adjacent explosion",skeleton.isAlive());
        log("FLOOR SIX FIRST SKELETON DEFEATED");
        for(int c:new int[]{841,840,840})click(c);
        Item strength=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfStrength.class);assertNotNull(strength);
        strength.execute(Dungeon.hero,"DRINK");ready();log("DRINK THIRD EARNED STRENGTH POTION");assertEquals(13,Dungeon.hero.STR);
        for(int c:new int[]{871,903,903,904,904})click(c);
        if(System.getProperty("route.checkpoint6SkeletonOut")!=null)writeCheckpoint(System.getProperty("route.checkpoint6SkeletonOut"));
    }

    private void postGooSection() throws Exception {
        assertEquals(5,Dungeon.depth);assertFalse(Dungeon.level.locked);
        for(int c:new int[]{743,743,743,709,709,674,673,672,637,637})click(c);
        assertEquals(3,Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class).quantity());
        for(int n=0;n<Integer.getInteger("route.postGooWait",100);n++)waitOne();
        for(int c:new int[]{603,569,535,501,500,499,465,431,430,429,428,427,426,425,424,423,422,421,420,386,352,351,350,349,383,384,418,417,416,415,381,381})click(c);
        assertEquals(6,Dungeon.depth);
        log("POST GOO PROGRESSION");
        System.out.println("FLOOR_LAYOUT "+new JSONObject().put("depth",Dungeon.depth).put("width",Dungeon.level.width()).put("height",Dungeon.level.height()).put("terrain",new JSONArray(Dungeon.level.map)).put("entrance",Dungeon.level.entrance()).put("exit",Dungeon.level.exit()));
        if(System.getProperty("route.checkpoint6Out")!=null)writeCheckpoint(System.getProperty("route.checkpoint6Out"));
    }

    private void armoredGooSection() throws Exception {
        assertEquals(5,Dungeon.depth);assertEquals(708,Dungeon.hero.pos);assertEquals(2,Dungeon.hero.belongings.armor().level());
        for(int n=0;n<200;n++)waitOne();
        Item food=Dungeon.hero.belongings.getItem(com.shatteredpixel.shatteredpixeldungeon.items.food.FrozenCarpaccio.class);assertNotNull(food);
        food.execute(Dungeon.hero,"EAT");ready();log("EAT REMAINING EARNED FROZEN MEAT BEFORE GOO");
        for(int c:new int[]{673,672,637})click(c);
        Dungeon.hero.search(true);ready();log("SEARCH GOO APPROACH SECRET DOOR");assertEquals(Terrain.DOOR,Dungeon.level.map[603]);
        for(int c:new int[]{603,569,535,501,500,499,465,431,430})click(c);
        Mob goo=Dungeon.level.mobs.stream().filter(m->m instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Goo).findFirst().get();
        assertEquals(100,goo.HP);log("GOO ARMORED LEGITIMATE FIRST ENCOUNTER");
        cast(HolyWard.INSTANCE,null);assertEquals(3,Dungeon.hero.shielding());
        if(Boolean.getBoolean("route.gooHolyWeapon"))cast(com.shatteredpixel.shatteredpixeldungeon.actors.hero.spells.HolyWeapon.INSTANCE,null);
        cast(GuidingLight.INSTANCE,goo.pos);
        throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,goo.pos);
        log("GOO ARMORED OPENING BURST");
        // Manually authored continuation; never chooses actions from game state.
        String verifiedActions="C431,C465,C499,C500,C501,C535,A,C569,C603,C637,A,C672,T,T,L,A,C707,C742,W,A,C777,C778,W,A,A,A,A,A";
        for(String action:System.getProperty("route.gooActions", Boolean.getBoolean("route.assertGooDefeated")?verifiedActions:"").split(",")){
            if(action.isEmpty())continue;
            if(action.equals("W"))waitOne();
            else if(action.equals("S"))cast(ShieldOfLight.INSTANCE,goo.pos);
            else if(action.equals("L"))cast(GuidingLight.INSTANCE,goo.pos);
            else if(action.equals("T"))throwItem(com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Shuriken.class,goo.pos);
            else if(action.equals("A"))click(goo.pos);
            else if(action.startsWith("C"))click(Integer.parseInt(action.substring(1)));
            else fail("Unknown manually authored action "+action);
        }
        if(Boolean.getBoolean("route.assertGooDefeated")){
            assertFalse(goo.isAlive());assertFalse(Dungeon.level.locked);assertEquals(1,Dungeon.hero.HP);
            log("GOO DEFEATED WITH CONTINUOUS EARNED RESOURCES");
            if(System.getProperty("route.checkpointGooOut")!=null)writeCheckpoint(System.getProperty("route.checkpointGooOut"));
        }
    }

}

